<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); bloginfo('name'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <!-- Innovative Header -->
    <header class="site-header">
        <div class="container header-container">
            <div class="logo-container">
                <div class="logo-orb">C</div>
                <div class="logo-text">CyanoraWP</div>
            </div>
            
            <nav class="circular-nav">
                <div class="nav-circle">
                    <a href="#" class="nav-item active">Home</a>
                    <a href="#" class="nav-item">Features</a>
                    <a href="#" class="nav-item">Showcase</a>
                    <a href="#" class="nav-item">Testimonials</a>
                    <a href="#" class="nav-item">Contact</a>
                </div>
            </nav>
            
            <div class="header-actions">
                <a href="#" class="action-btn">Get Started</a>
            </div>
        </div>
    </header>