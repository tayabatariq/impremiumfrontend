    </main>
    
    <footer class="site-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <div class="footer-logo">Newus<span>Flow</span></div>
                    <p>Your premier destination for quality products and exceptional shopping experience.</p>
                </div>
                
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <a href="<?php echo home_url(); ?>">Home</a>
                    <a href="<?php echo home_url('/shipping-policy'); ?>">Shipping Policy</a>
                    <a href="<?php echo home_url('/shop'); ?>">Shop</a>
                    <a href="<?php echo home_url('/returns-refunds'); ?>">Returns & Refunds</a>
                    <a href="<?php echo home_url('/about-us'); ?>">About Us</a>
                    <a href="<?php echo home_url('/terms-of-service'); ?>">Terms of Service</a>
                    <a href="<?php echo home_url('/contact'); ?>">Contact</a>
                    <a href="<?php echo home_url('/privacy-policy'); ?>">Privacy Policy</a>
                    <a href="<?php echo home_url('/faq'); ?>">FAQ</a>
                    <a href="<?php echo home_url('/track-order'); ?>">Track Your Order</a>
                </div>
                
                <div class="footer-contact">
                    <h4>Customer Service</h4>
                    <div class="contact-info">
                        <div class="contact-item">
                            <span class="contact-icon">📍</span>
                            <span>123 Commerce St. City, State 12345</span>
                        </div>
                        <div class="contact-item">
                            <span class="contact-icon">📞</span>
                            <span>+1 (555) 123-4567</span>
                        </div>
                        <div class="contact-item">
                            <span class="contact-icon">✉️</span>
                            <span>support@newusflow.com</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; <?php echo date('Y'); ?> NewusFlow. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <?php wp_footer(); ?>
</body>
</html>