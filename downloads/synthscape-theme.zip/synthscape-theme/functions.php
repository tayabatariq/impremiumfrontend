<?php
/**
 * SynthScape Theme functions and definitions
 *
 * @package SynthScape
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Theme setup
function synthscape_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'synthscape'),
        'footer' => __('Footer Menu', 'synthscape')
    ));
}
add_action('after_setup_theme', 'synthscape_theme_setup');

// Enqueue styles and scripts
function synthscape_theme_scripts() {
    wp_enqueue_style('synthscape-style', get_stylesheet_uri());
    wp_enqueue_script('synthscape-script', get_template_directory_uri() . '/script.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'synthscape_theme_scripts');

// Custom navigation menu filter
function synthscape_custom_menu($nav_menu, $args) {
    if ($args->theme_location == 'primary') {
        // Remove all list items and extract just the links
        $nav_menu = strip_tags($nav_menu, '<a>');
        // Add our custom class to all links
        $nav_menu = preg_replace('/<a(.*?)>/', '<a$1 class="nav-item">', $nav_menu);
    }
    return $nav_menu;
}
add_filter('wp_nav_menu', 'synthscape_custom_menu', 10, 2);

// Simple fallback menu
function synthscape_primary_menu_fallback() {
    $menu_items = array(
        'Home' => home_url(),
        'Features' => '#features',
        'Gallery' => '#gallery',
        'Showcase' => '#showcase',
        'Contact' => '#contact'
    );
    
    $menu_output = '';
    foreach ($menu_items as $title => $url) {
        $menu_output .= '<a href="' . esc_url($url) . '" class="nav-item">' . esc_html($title) . '</a>';
    }
    return $menu_output;
}