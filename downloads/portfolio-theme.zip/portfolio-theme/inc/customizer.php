<?php
/**
 * Theme Customizer
 */

function portfolio_theme_customizer($wp_customize) {
    // Colors Section
    $wp_customize->add_section('portfolio_colors', array(
        'title' => __('Theme Colors', 'portfolio-theme'),
        'priority' => 30,
    ));
    
    // Primary Color
    $wp_customize->add_setting('primary_color', array(
        'default' => '#6c63ff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label' => __('Primary Color', 'portfolio-theme'),
        'section' => 'portfolio_colors',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('secondary_color', array(
        'default' => '#ff6584',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', array(
        'label' => __('Secondary Color', 'portfolio-theme'),
        'section' => 'portfolio_colors',
    )));
    
    // Accent Color
    $wp_customize->add_setting('accent_color', array(
        'default' => '#42e6ff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'accent_color', array(
        'label' => __('Accent Color', 'portfolio-theme'),
        'section' => 'portfolio_colors',
    )));
    
    // Background Color
    $wp_customize->add_setting('bg_color', array(
        'default' => '#0f0c29',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'bg_color', array(
        'label' => __('Background Color', 'portfolio-theme'),
        'section' => 'portfolio_colors',
    )));
    
    // Text Color
    $wp_customize->add_setting('text_color', array(
        'default' => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'text_color', array(
        'label' => __('Text Color', 'portfolio-theme'),
        'section' => 'portfolio_colors',
    )));
    
    // Hero Section
    $wp_customize->add_section('portfolio_hero', array(
        'title' => __('Hero Section', 'portfolio-theme'),
        'priority' => 40,
    ));
    
    // Hero Title
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Portfolio',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'portfolio-theme'),
        'section' => 'portfolio_hero',
        'type' => 'text',
    ));
    
    // Hero Description
    $wp_customize->add_setting('hero_description', array(
        'default' => 'A dynamic showcase of creative work where each project reveals its unique visual signature through adaptive color systems.',
        'sanitize_callback' => 'wp_kses_post',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'portfolio-theme'),
        'section' => 'portfolio_hero',
        'type' => 'textarea',
    ));
    
    // Portfolio Section
    $wp_customize->add_section('portfolio_portfolio', array(
        'title' => __('Portfolio Section', 'portfolio-theme'),
        'priority' => 45,
    ));
    
    $wp_customize->add_setting('portfolio_section_title', array(
        'default' => 'Featured Projects',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control('portfolio_section_title', array(
        'label' => __('Portfolio Section Title', 'portfolio-theme'),
        'section' => 'portfolio_portfolio',
        'type' => 'text',
    ));
    
    // Timeline Section
    $wp_customize->add_section('portfolio_timeline', array(
        'title' => __('Timeline Section', 'portfolio-theme'),
        'priority' => 46,
    ));
    
    $wp_customize->add_setting('timeline_section_title', array(
        'default' => 'Creative Journey',
        'sanitize_callback' => 'sanitize_text_field',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control('timeline_section_title', array(
        'label' => __('Timeline Section Title', 'portfolio-theme'),
        'section' => 'portfolio_timeline',
        'type' => 'text',
    ));
    
    // Social Media Section
    $wp_customize->add_section('portfolio_social', array(
        'title' => __('Social Media', 'portfolio-theme'),
        'priority' => 50,
    ));
    
    $social_platforms = array(
        'twitter' => 'Twitter',
        'facebook' => 'Facebook',
        'instagram' => 'Instagram',
        'linkedin' => 'LinkedIn',
        'github' => 'GitHub',
        'dribbble' => 'Dribbble',
        'behance' => 'Behance',
    );
    
    foreach ($social_platforms as $platform => $name) {
        $wp_customize->add_setting("social_$platform", array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw',
        ));
        
        $wp_customize->add_control("social_$platform", array(
            'label' => $name . ' URL',
            'section' => 'portfolio_social',
            'type' => 'url',
        ));
    }
    
    // Footer Section
    $wp_customize->add_section('portfolio_footer', array(
        'title' => __('Footer', 'portfolio-theme'),
        'priority' => 60,
    ));
    
    $wp_customize->add_setting('footer_text', array(
        'default' => '© 2023 Portfolio. All rights reserved.',
        'sanitize_callback' => 'wp_kses_post',
        'transport' => 'postMessage',
    ));
    
    $wp_customize->add_control('footer_text', array(
        'label' => __('Footer Text', 'portfolio-theme'),
        'section' => 'portfolio_footer',
        'type' => 'textarea',
    ));
    
    // Advanced Settings Section
    $wp_customize->add_section('portfolio_advanced', array(
        'title' => __('Advanced Settings', 'portfolio-theme'),
        'priority' => 100,
    ));
    
    // Enable/Disable Animations
    $wp_customize->add_setting('enable_animations', array(
        'default' => true,
        'sanitize_callback' => 'portfolio_sanitize_checkbox',
    ));
    
    $wp_customize->add_control('enable_animations', array(
        'label' => __('Enable Animations', 'portfolio-theme'),
        'section' => 'portfolio_advanced',
        'type' => 'checkbox',
    ));
    
    // Custom CSS
    $wp_customize->add_setting('custom_css', array(
        'default' => '',
        'sanitize_callback' => 'wp_strip_all_tags',
    ));
    
    $wp_customize->add_control('custom_css', array(
        'label' => __('Custom CSS', 'portfolio-theme'),
        'section' => 'portfolio_advanced',
        'type' => 'textarea',
    ));
}

add_action('customize_register', 'portfolio_theme_customizer');

// Sanitization functions
function portfolio_sanitize_checkbox($input) {
    return (isset($input) && true == $input) ? true : false;
}

// Output custom CSS from customizer
function portfolio_customizer_css() {
    ?>
    <style type="text/css">
        :root {
            --primary-color: <?php echo esc_attr(get_theme_mod('primary_color', '#6c63ff')); ?>;
            --secondary-color: <?php echo esc_attr(get_theme_mod('secondary_color', '#ff6584')); ?>;
            --accent-color: <?php echo esc_attr(get_theme_mod('accent_color', '#42e6ff')); ?>;
            --bg-color: <?php echo esc_attr(get_theme_mod('bg_color', '#0f0c29')); ?>;
            --text-color: <?php echo esc_attr(get_theme_mod('text_color', '#ffffff')); ?>;
        }
        
        <?php if (!get_theme_mod('enable_animations', true)) : ?>
        .hero h1,
        .portfolio-item,
        .timeline-content {
            animation: none !important;
        }
        <?php endif; ?>
        
        <?php echo wp_strip_all_tags(get_theme_mod('custom_css', '')); ?>
    </style>
    <?php
}
add_action('wp_head', 'portfolio_customizer_css');