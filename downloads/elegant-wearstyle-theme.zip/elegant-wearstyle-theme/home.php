<?php
/**
 * Home Page Template
 * This template is used for the homepage
 */

get_header();
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <div class="hero-text">
                <div class="hero-badge">New Collection</div>
                <h1 class="hero-title">Elevate Your Everyday Style</h1>
                <p class="hero-description">Discover premium clothing crafted with attention to detail, designed for comfort and sophistication in your daily life.</p>
                <div class="hero-buttons">
                    <div class="hero-buttons">
    <a href="<?php echo esc_url(home_url('/collections')); ?>" class="button-primary">Shop Collection →</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>" class="button-secondary">Learn More</a>
</div>
                </div>
            </div>
            <div class="hero-image">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/images/clothing-rack-1.webp'); ?>" alt="Premium Clothing Collection" onerror="this.style.display='none'">
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <div class="section-subtitle">WHY CHOOSE US</div>
            <h2 class="section-title">Crafted with Excellence</h2>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">✓</div>
                <h3 class="feature-title">Premium Materials</h3>
                <p class="feature-description">We source only the finest fabrics that ensure comfort, durability, and a luxurious feel.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">✂️</div>
                <h3 class="feature-title">Expert Craftsmanship</h3>
                <p class="feature-description">Each garment is meticulously constructed by skilled artisans with attention to every detail.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🌱</div>
                <h3 class="feature-title">Sustainable Practices</h3>
                <p class="feature-description">We're committed to ethical production and minimizing our environmental footprint.</p>
            </div>
        </div>
    </div>
</section>

<!-- Collections Section -->
<section class="collections">
    <div class="container">
        <div class="section-header">
            <div class="section-subtitle">EXPLORE</div>
            <h2 class="section-title">Our Collections</h2>
        </div>
        <div class="collections-grid">
            <div class="collection-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/images/mens-shirts-display.jpg'); ?>" alt="Men's Collection" class="collection-image" onerror="this.style.display='none'">
                <div class="collection-overlay">
                    <h3 class="collection-title">Men's Collection</h3>
                    <p class="collection-description">Sophisticated styles for the modern man</p>
                    <a href="<?php echo esc_url(home_url('/mens-collection')); ?>" class="collection-link">Explore →</a>
                </div>
            </div>
            <div class="collection-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/images/womens-dresses-display.jpeg'); ?>" alt="Women's Collection" class="collection-image" onerror="this.style.display='none'">
                <div class="collection-overlay">
                    <h3 class="collection-title">Women's Collection</h3>
                    <p class="collection-description">Elegant designs for everyday wear</p>
                    <a href="<?php echo esc_url(home_url('/womens-collection')); ?>" class="collection-link">Explore →</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <h2 class="cta-title">Ready to Elevate Your Wardrobe?</h2>
        <p class="cta-description">Join thousands of satisfied customers who have discovered the Clothings difference. Sign up for exclusive offers and early access to new collections.</p>
        <a href="<?php echo esc_url(home_url('/signup')); ?>" class="cta-button">Sign Up Now</a>
    </div>
</section>

<?php get_footer(); ?>