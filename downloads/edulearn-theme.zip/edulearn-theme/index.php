<?php get_header(); ?>

    <!-- Popular Courses Section -->
    <section class="popular-courses">
        <div class="container">
            <div class="section-title">
                <h2>Popular Courses</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel adipiscing ipsum. Nam neque purus, tincid</p>
            </div>
            <div class="courses-container">
                <?php
                $courses = get_posts(array(
                    'post_type' => 'course',
                    'numberposts' => 3,
                    'orderby' => 'date',
                    'order' => 'DESC'
                ));
                
                foreach ($courses as $course) {
                    $icon = get_post_meta($course->ID, 'course_icon', true) ?: 'fas fa-book';
                    ?>
                    <div class="course-card">
                        <div class="course-icon">
                            <i class="<?php echo esc_attr($icon); ?>"></i>
                        </div>
                        <div class="course-content">
                            <h3><?php echo $course->post_title; ?></h3>
                            <p><?php echo wp_trim_words($course->post_excerpt, 20); ?></p>
                            <a href="<?php echo get_permalink($course->ID); ?>" class="course-link">Learn More <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Online Learning Section -->
    <section class="online-learning">
        <div class="container">
            <div class="learning-content">
                <h2>Learn Online</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br>Etiam vel adipiscing ipsum. Nam neque purus, tincid.</p>
                
                <hr class="section-divider">
                
                <h3>Get Started</h3>
                
                <hr class="section-divider">
                
                <div class="platform-display">
                    <h3>Online Learning Platform</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials">
        <div class="container">
            <div class="section-title">
                <h2>What Our Students Say</h2>
                <p>Hear from our successful students who have transformed their careers with our courses</p>
            </div>
            <div class="testimonial-container">
                <?php
                $testimonials = get_posts(array(
                    'post_type' => 'testimonial',
                    'numberposts' => 3,
                    'orderby' => 'date',
                    'order' => 'DESC'
                ));
                
                if ($testimonials) {
                    foreach ($testimonials as $testimonial) {
                        $author = get_post_meta($testimonial->ID, 'testimonial_author', true);
                        $position = get_post_meta($testimonial->ID, 'testimonial_position', true);
                        $initials = get_initials($author);
                        ?>
                        <div class="testimonial-card">
                            <div class="testimonial-text">
                                <?php echo wp_trim_words($testimonial->post_content, 25); ?>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-avatar"><?php echo $initials; ?></div>
                                <div class="author-info">
                                    <h4><?php echo $author; ?></h4>
                                    <p><?php echo $position; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    // Default testimonials
                    echo '
                    <div class="testimonial-card">
                        <div class="testimonial-text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel adipiscing ipsum. Nam neque purus, tincidunt non nisi dapibus.
                        </div>
                        <div class="testimonial-author">
                            <div class="author-avatar">JS</div>
                            <div class="author-info">
                                <h4>John Smith</h4>
                                <p>Web Developer</p>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-card">
                        <div class="testimonial-text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel adipiscing ipsum. Nam neque purus, tincidunt non nisi dapibus.
                        </div>
                        <div class="testimonial-author">
                            <div class="author-avatar">SJ</div>
                            <div class="author-info">
                                <h4>Sarah Johnson</h4>
                                <p>Graphic Designer</p>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-card">
                        <div class="testimonial-text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel adipiscing ipsum. Nam neque purus, tincidunt non nisi dapibus.
                        </div>
                        <div class="testimonial-author">
                            <div class="author-avatar">MD</div>
                            <div class="author-info">
                                <h4>Michael Davis</h4>
                                <p>Data Scientist</p>
                            </div>
                        </div>
                    </div>';
                }
                ?>
            </div>
        </div>
    </section>

<?php get_footer(); ?>