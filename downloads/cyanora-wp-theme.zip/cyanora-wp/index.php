<?php get_header(); ?>

<!-- Unique Hero Section -->
<section class="hero-section">
    <div class="hero-background"></div>
    <div class="hero-particles" id="particles"></div>
    <div class="container">
        <div class="hero-content">
            <div class="hero-badge">PREMIUM WORDPRESS THEME</div>
            <h1 class="hero-title">Experience Digital Innovation</h1>
            <p class="hero-description">CyanoraWP redefines modern web design with its sophisticated teal palette and innovative layout system. Create stunning websites that captivate and convert.</p>
            <div class="hero-actions">
                <a href="#" class="btn btn-primary">
                    <i class="fas fa-rocket"></i>
                    Explore Demos
                </a>
                <a href="#" class="btn btn-secondary">
                    <i class="fas fa-play-circle"></i>
                    Watch Intro
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Hexagon Features Section -->
<section class="features-section">
    <div class="container">
        <div class="section-header">
            <div class="section-subtitle">Why Choose CyanoraWP</div>
            <h2 class="section-title">Designed for Digital Excellence</h2>
            <p class="section-description">Experience the perfect blend of dark aesthetics and cyanora elegance with our unique approach to web design.</p>
        </div>
        
        <div class="hexagon-grid">
            <div class="hexagon-item">
                <div class="feature-icon">
                    <i class="fas fa-palette"></i>
                </div>
                <h3 class="feature-title">Cyanora Palette</h3>
                <p class="feature-description">Sophisticated teal color scheme with elegant gradients and modern aesthetics.</p>
            </div>
            
            <div class="hexagon-item">
                <div class="feature-icon">
                    <i class="fas fa-layer-group"></i>
                </div>
                <h3 class="feature-title">Hexagon Layout</h3>
                <p class="feature-description">Unique hexagonal grid system for visual interest and enhanced engagement.</p>
            </div>
            
            <div class="hexagon-item">
                <div class="feature-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <h3 class="feature-title">Lightning Fast</h3>
                <p class="feature-description">Optimized for maximum performance with minimal code and efficient design patterns.</p>
            </div>
            
            <div class="hexagon-item">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h3 class="feature-title">Fully Responsive</h3>
                <p class="feature-description">Looks stunning on all devices with mobile-first adaptive design principles.</p>
            </div>
            
            <div class="hexagon-item">
                <div class="feature-icon">
                    <i class="fas fa-cog"></i>
                </div>
                <h3 class="feature-title">Easy Customization</h3>
                <p class="feature-description">Intuitive customization options that offer powerful flexibility without coding.</p>
            </div>
            
            <div class="hexagon-item">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3 class="feature-title">Secure & Stable</h3>
                <p class="feature-description">Built with security best practices and thoroughly tested for reliability.</p>
            </div>
        </div>
    </div>
</section>

<!-- Showcase Section -->
<section class="showcase-section">
    <div class="container">
        <div class="showcase-container">
            <div class="showcase-content">
                <h2 class="showcase-title">Transform Your Digital Presence</h2>
                <p class="showcase-description">CyanoraWP isn't just another WordPress theme. It's a complete design system that empowers you to create unique, engaging websites that capture attention and convert visitors.</p>
                <p class="showcase-description">With our innovative approach to layout and the sophisticated cyanora color palette, you can break free from the constraints of traditional web design and create something truly remarkable.</p>
                <a href="#" class="btn btn-primary">
                    <i class="fas fa-eye"></i>
                    View Showcase
                </a>
            </div>
            <div class="showcase-image">
                <div class="floating-card">
                    <div class="card-gradient">
                        <i class="fas fa-desktop" style="font-size: 3rem; margin-right: 1rem; z-index: 2; position: relative;"></i>
                        <span style="z-index: 2; position: relative;">CyanoraWP Layout Preview</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials-section">
    <div class="container">
        <div class="section-header">
            <div class="section-subtitle">What Our Users Say</div>
            <h2 class="section-title">Loved by Designers & Developers</h2>
        </div>
        
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <p class="testimonial-content">CyanoraWP completely transformed how I approach modern web design. The unique color system and hexagonal layout options helped me create websites that stand out from the competition.</p>
                <div class="testimonial-author">
                    <div class="author-avatar">SD</div>
                    <div class="author-info">
                        <h4>Sarah Johnson</h4>
                        <p>Creative Director</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <p class="testimonial-content">I've tried countless WordPress themes, but CyanoraWP is the first one that truly feels innovative. The hexagon grid system alone is worth the investment.</p>
                <div class="testimonial-author">
                    <div class="author-avatar">MR</div>
                    <div class="author-info">
                        <h4>Michael Rodriguez</h4>
                        <p>Web Developer</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <p class="testimonial-content">The sophisticated cyanora palette is exactly what my clients have been asking for. It's professional, modern, and elegant all at once.</p>
                <div class="testimonial-author">
                    <div class="author-avatar">EC</div>
                    <div class="author-info">
                        <h4>Emily Chen</h4>
                        <p>Brand Strategist</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="cta-pattern"></div>
    <div class="container">
        <div class="cta-content">
            <h2 class="cta-title">Ready to Transform Your Website?</h2>
            <p class="cta-description">Join thousands of designers and developers who are already creating stunning websites with CyanoraWP.</p>
            <a href="#" class="cta-button">
                <i class="fas fa-download"></i>
                Download CyanoraWP
            </a>
        </div>
    </div>
</section>

<?php get_footer(); ?>