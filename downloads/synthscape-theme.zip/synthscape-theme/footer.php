<?php
/**
 * The template for displaying the footer
 *
 * @package SynthScape
 */
?>
        <footer>
            <div class="footer-links">
                <?php
                // Simple footer menu fallback function
                function synthscape_footer_menu_fallback() {
                    $menu_items = array(
                        'Privacy Policy' => '#privacy',
                        'Terms of Service' => '#terms', 
                        'Contact Us' => '#contact',
                        'GitHub' => '#github'
                    );
                    
                    foreach ($menu_items as $title => $url) {
                        echo '<a href="' . esc_url($url) . '" class="footer-link">' . esc_html($title) . '</a>';
                    }
                }
                
                if (has_nav_menu('footer')) {
                    wp_nav_menu(array(
                        'theme_location' => 'footer',
                        'container' => false,
                        'items_wrap' => '<div class="footer-menu-items">%3$s</div>',
                        'fallback_cb' => 'synthscape_footer_menu_fallback'
                    ));
                } else {
                    synthscape_footer_menu_fallback();
                }
                ?>
            </div>
            <p>&copy; <?php echo date('Y'); ?> SynthScape. All rights reserved. A completely original and compact theme.</p>
        </footer>
    </div><!-- .container -->
    
    <?php wp_footer(); ?>
</body>
</html>