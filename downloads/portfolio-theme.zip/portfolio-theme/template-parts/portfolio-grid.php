<section class="portfolio-section">
    <h2 class="section-title"><?php echo esc_html(get_theme_mod('portfolio_section_title', 'Featured Projects')); ?></h2>
    
    <div class="portfolio-grid">
        <?php
        $portfolio_args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => 6,
            'meta_query' => array(
                array(
                    'key' => '_featured_portfolio',
                    'value' => 'yes',
                )
            )
        );
        $portfolio_query = new WP_Query($portfolio_args);
        
        if ($portfolio_query->have_posts()) :
            while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                $icon = get_post_meta(get_the_ID(), 'portfolio_icon', true);
        ?>
            <div class="portfolio-item">
                <a href="<?php the_permalink(); ?>">
                    <div class="item-content">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="portfolio-image">
                                <?php the_post_thumbnail('portfolio-medium'); ?>
                            </div>
                        <?php endif; ?>
                        
                        <i class="<?php echo esc_attr($icon ?: 'fas fa-palette'); ?>"></i>
                        <h3><?php the_title(); ?></h3>
                        <p><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                    </div>
                </a>
            </div>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            // Fallback content
        ?>
            <div class="portfolio-item">
                <div class="item-content">
                    <i class="fas fa-palette"></i>
                    <h3>Color Dynamics</h3>
                    <p>Interactive color extraction system</p>
                </div>
            </div>
            <div class="portfolio-item">
                <div class="item-content">
                    <i class="fas fa-cube"></i>
                    <h3>3D Visualization</h3>
                    <p>Immersive project presentations</p>
                </div>
            </div>
            <div class="portfolio-item">
                <div class="item-content">
                    <i class="fas fa-wave-square"></i>
                    <h3>Kinetic Interface</h3>
                    <p>Dynamic, responsive layouts</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>