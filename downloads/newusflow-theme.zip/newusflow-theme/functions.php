<?php
/**
 * NewusFlow Theme functions and definitions
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme setup
function newusflow_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // WooCommerce support
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'newusflow'),
        'footer' => __('Footer Menu', 'newusflow')
    ));
    
    // Add theme support for custom background
    add_theme_support('custom-background');
}
add_action('after_setup_theme', 'newusflow_theme_setup');

// Enqueue styles
function newusflow_enqueue_styles() {
    wp_enqueue_style('newusflow-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'newusflow_enqueue_styles');

// Customizer settings
function newusflow_customize_register($wp_customize) {
    // Hero Section
    $wp_customize->add_section('newusflow_hero_section', array(
        'title' => __('Hero Section', 'newusflow'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Elevate Your Shopping Experience',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'newusflow'),
        'section' => 'newusflow_hero_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_description', array(
        'default' => 'Discover the latest trends with our curated collection of premium products. From fashion to electronics, we bring you the best from around the world.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'newusflow'),
        'section' => 'newusflow_hero_section',
        'type' => 'textarea',
    ));
}
add_action('customize_register', 'newusflow_customize_register');

// Default menu fallback
function newusflow_default_menu() {
    echo '<ul class="nav-menu">';
    echo '<li><a href="'.home_url().'">Home</a></li>';
    echo '<li><a href="'.home_url('/shop').'">Shop</a></li>';
    echo '<li><a href="'.home_url('/categories').'">Categories</a></li>';
    echo '<li><a href="'.home_url('/new-arrivals').'">New Arrivals</a></li>';
    echo '<li><a href="'.home_url('/deals').'">Deals</a></li>';
    echo '</ul>';
}
?>