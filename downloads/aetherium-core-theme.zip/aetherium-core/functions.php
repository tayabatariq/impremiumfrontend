<?php
/**
 * AetheriumCore functions and definitions
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Theme setup
function aetheriumcore_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'aetheriumcore'),
    ));
}
add_action('after_setup_theme', 'aetheriumcore_setup');

// Enqueue styles and scripts
function aetheriumcore_scripts() {
    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
    
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&display=swap');
    
    // Enqueue main stylesheet
    wp_enqueue_style('aetheriumcore-style', get_stylesheet_uri());
    
    // Enqueue custom JavaScript
    wp_enqueue_script('aetheriumcore-custom', get_template_directory_uri() . '/js/custom.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'aetheriumcore_scripts');

// Custom excerpt length
function aetheriumcore_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'aetheriumcore_excerpt_length');

// Custom excerpt more
function aetheriumcore_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'aetheriumcore_excerpt_more');
?>