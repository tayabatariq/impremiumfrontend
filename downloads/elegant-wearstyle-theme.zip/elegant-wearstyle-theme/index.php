<?php get_header(); ?>

<div class="container">
    <div class="page-content">
        <?php if (have_posts()) : ?>
            <div class="blog-posts">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="blog-post">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="post-meta">
                            <span>Posted on <?php echo get_the_date(); ?></span>
                        </div>
                        <div class="post-content">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="button-primary">Read More</a>
                    </article>
                <?php endwhile; ?>
            </div>
            
            <div class="pagination">
                <?php the_posts_pagination(); ?>
            </div>
        <?php else : ?>
            <div class="page-title">Blog</div>
            <p class="page-text">No posts found.</p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>