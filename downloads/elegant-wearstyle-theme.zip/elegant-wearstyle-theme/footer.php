</main>

<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-brand">
                <div class="footer-logo">Elegant<span>WearStyle</span></div>
                <p class="footer-description">Premium clothing designed for everyday elegance and comfort. Crafted with care, worn with confidence.</p>
                <div class="social-links">
                    <a href="#" class="social-link">fb</a>
                    <a href="#" class="social-link">ig</a>
                    <a href="#" class="social-link">tw</a>
                </div>
            </div>
            
            <div class="footer-links-column">
                <h4 class="footer-heading">Shop</h4>
                <ul class="footer-links">
                    <li><a href="#">New Arrivals</a></li>
                    <li><a href="#">Mens Collection</a></li>
                    <li><a href="#">Womens Collection</a></li>
                    <li><a href="#">Accessories</a></li>
                    <li><a href="#">Sale</a></li>
                </ul>
            </div>
            
            <div class="footer-links-column">
                <h4 class="footer-heading">Information</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url(home_url('/about')); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact Us</a></li>
                    <li><a href="#">Shipping & Returns</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                </ul>
            </div>
            
            <div class="footer-contact">
                <h4 class="footer-heading">Contact</h4>
                <p>123 Fashion Avenue, New York, NY 10001</p>
                <p>+1 (595) 123-4567</p>
                <p>hello@elegantwearstyle.com</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2023 ElegantWearStyle. All rights reserved.</p>
            <div class="footer-bottom-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
                <a href="#">Cookie Policy</a>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>