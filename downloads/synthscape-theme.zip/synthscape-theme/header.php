<?php
/**
 * The header for our theme
 *
 * @package SynthScape
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?> | <?php bloginfo('description'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div class="container">
        <header>
            <h1 class="logo">SYNTHSCAPE</h1>
            <p class="tagline">A compact digital experience where innovation meets aesthetic perfection</p>
            
            <nav class="main-navigation">
                <div class="nav-items">
                    <a href="<?php echo home_url(); ?>" class="nav-item">Home</a>
                    <a href="#blog" class="nav-item">Blog</a>
                    <a href="#contact" class="nav-item">Contact</a>
                    <a href="#features" class="nav-item">Features</a>
                    <a href="#showcase" class="nav-item">Showcase</a>
                    <a href="#get-started" class="nav-item get-started-btn">Get Started</a>
                </div>
            </nav>
        </header>