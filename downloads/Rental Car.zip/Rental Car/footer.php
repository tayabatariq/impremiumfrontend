<footer id="colophon" class="site-footer">
    <div class="container">
        <div class="footer-content">
            
        
                        
            <div class="footer-widgets">
                <!-- Column 1: Services -->
                <div class="footer-column">
                    <?php if (is_active_sidebar('footer-1')) : ?>
                        <?php dynamic_sidebar('footer-1'); ?>
                    <?php else : ?>
                        <div class="service-item">
                            <h4>Affordable Rates</h4>
                            <p>Competitive pricing with no hidden fees</p>
                        </div>
                        <div class="footer-divider"></div>
                        <div class="service-item">
                            <h4>24/7 Customer Support</h4>
                            <p>Round-the-clock assistance for all your needs</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Column 2: Navigation -->
                <div class="footer-column">
                    <?php if (is_active_sidebar('footer-2')) : ?>
                        <?php dynamic_sidebar('footer-2'); ?>
                    <?php else : ?>
                        <h3>Quick Links</h3>
                        <ul class="footer-links">
                            <li class="menu-item"><a href="#">Home</a></li>
                            <li class="menu-item"><a href="#">Our Services</a></li>
                            <li class="menu-item"><a href="#">CONTACT US</a></li>
                            <li class="menu-item"><a href="#">About US</a></li>
                        </ul>
                    <?php endif; ?>
                </div>
                
                <!-- Column 3: Services Continued -->
                <div class="footer-column">
                    <?php if (is_active_sidebar('footer-3')) : ?>
                        <?php dynamic_sidebar('footer-3'); ?>
                    <?php else : ?>
                        <div class="service-item">
                            <h4>Easy Booking Process</h4>
                            <p>Simple and quick reservation system</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Bottom Copyright -->
            <div class="site-info">
                <div class="copyright">
                    <?php echo wp_kses_post(get_theme_mod('footer_copyright', '© 2025 Rental Car. All rights reserved.')); ?>
                </div>
                <div class="social-links">
                    <?php
                    $social_platforms = array('facebook', 'twitter', 'instagram', 'linkedin');
                    foreach ($social_platforms as $platform) {
                        $url = get_theme_mod($platform . '_url');
                        if ($url) {
                            echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener"><i class="fab fa-' . esc_attr($platform) . '"></i></a>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</footer>