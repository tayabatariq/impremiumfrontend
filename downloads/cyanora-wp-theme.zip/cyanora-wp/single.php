<?php
/**
 * The template for displaying single posts
 *
 * @package CyanoraWP
 */

get_header();
?>

<main id="main" class="site-main">
    <section class="hero-section" style="padding: 6rem 0 4rem;">
        <div class="hero-background"></div>
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title" style="font-size: 3.5rem;"><?php the_title(); ?></h1>
                <div class="hero-badge">
                    <i class="fas fa-calendar"></i>
                    <?php echo get_the_date(); ?>
                    <i class="fas fa-user" style="margin-left: 1rem;"></i>
                    <?php the_author(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="features-section" style="padding: 4rem 0;">
        <div class="container">
            <div class="features-grid">
                <article class="feature-card">
                    <div class="feature-content">
                        <?php
                        if (have_posts()) :
                            while (have_posts()) : the_post();
                                the_content();
                                
                                // Post navigation
                                the_post_navigation(array(
                                    'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'cyanorawp') . '</span> <span class="nav-title">%title</span>',
                                    'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'cyanorawp') . '</span> <span class="nav-title">%title</span>',
                                ));
                                
                                // If comments are open or we have at least one comment, load up the comment template.
                                if (comments_open() || get_comments_number()) :
                                    comments_template();
                                endif;
                                
                            endwhile;
                        else :
                            echo '<p>' . esc_html__('No post found.', 'cyanorawp') . '</p>';
                        endif;
                        ?>
                    </div>
                </article>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>