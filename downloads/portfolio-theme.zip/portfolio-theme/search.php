<?php get_header(); ?>

<div class="container">
    <header class="page-header">
        <h1 class="page-title">
            <?php printf(__('Search Results for: %s', 'portfolio-theme'), '<span>' . get_search_query() . '</span>'); ?>
        </h1>
    </header>
    
    <?php if (have_posts()) : ?>
        <div class="search-results">
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class(); ?>>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="entry-summary"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
    <?php else : ?>
        <p><?php _e('No results found.', 'portfolio-theme'); ?></p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>