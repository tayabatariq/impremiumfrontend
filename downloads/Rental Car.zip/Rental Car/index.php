<?php get_header(); ?>

    <!-- Hero Section with Background Image -->
    <section class="hero" style="background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('<?php echo get_template_directory_uri(); ?>/assets/images/hero-bg.jpg'); background-size: cover; background-position: center;">
        <div class="container">
            <h1><?php echo get_theme_mod('hero_title', 'Rent a Car in Minutes'); ?></h1>
            <p><?php echo get_theme_mod('hero_description', 'Find the perfect vehicle for your needs at affordable prices'); ?></p>
            <a href="#" class="btn">View Cars</a>
        </div>
    </section>

    <!-- Featured Cars Section -->
    <section class="container">
        <h2 class="section-title">Featured Cars</h2>
        <div class="cars-grid">
            <div class="car-card">
                <div class="car-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/car1.jpg')"></div>
                <div class="car-info">
                    <h3>Toyota Camry</h3>
                    <div class="car-price">$50/day</div>
                    <a href="#" class="btn">Book Now</a>
                </div>
            </div>
            <div class="car-card">
                <div class="car-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/car2.jpg')"></div>
                <div class="car-info">
                    <h3>Honda CR-V</h3>
                    <div class="car-price">$65/day</div>
                    <a href="#" class="btn">Book Now</a>
                </div>
            </div>
            <div class="car-card">
                <div class="car-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/car3.jpg')"></div>
                <div class="car-info">
                    <h3>BMW 3 Series</h3>
                    <div class="car-price">$85/day</div>
                    <a href="#" class="btn">Book Now</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <h2 class="section-title">Why Choose Us</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-tag"></i>
                    </div>
                    <h3>Affordable Rates</h3>
                    <p>Competitive pricing with no hidden fees</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>24/7 Customer Support</h3>
                    <p>Round-the-clock assistance for all your needs</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h3>Easy Booking Process</h3>
                    <p>Simple and quick reservation system</p>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>