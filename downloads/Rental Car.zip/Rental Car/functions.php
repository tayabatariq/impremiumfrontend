<?php
/**
 * Rental Car Theme functions and definitions
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Theme setup
function rental_theme_setup() {
    // Make theme available for translation
    load_theme_textdomain('rental-car', get_template_directory() . '/languages');
    
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails on posts and pages
    add_theme_support('post-thumbnails');
    
    // Add support for custom logo
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary-menu' => __('Primary Menu', 'rental-car'),
        'footer-menu' => __('Footer Menu', 'rental-car'),
        'mobile-menu' => __('Mobile Menu', 'rental-car')
    ));
    
    // Switch default core markup for search form, comment form, and comments to output valid HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Add theme support for selective refresh for widgets
    add_theme_support('customize-selective-refresh-widgets');
    
    // Add support for core custom logo
    add_theme_support('custom-logo', array(
        'height'      => 250,
        'width'       => 250,
        'flex-width'  => true,
        'flex-height' => true,
    ));
    
    // Add support for WooCommerce
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    
    // Add support for Block Styles
    add_theme_support('wp-block-styles');
    
    // Add support for full and wide align images
    add_theme_support('align-wide');
    
    // Add support for editor styles
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-style.css');
    
    // Add custom image sizes
    add_image_size('rental-blog-thumbnail', 400, 250, true);
    add_image_size('rental-car-large', 800, 500, true);
}
add_action('after_setup_theme', 'rental_theme_setup');

// Set content width
if (!isset($content_width)) {
    $content_width = 1200;
}

// Enqueue scripts and styles
function rental_theme_scripts() {
    // Main stylesheet
    wp_enqueue_style('rental-main-style', get_template_directory_uri() . '/assets/css/main.css', array(), '1.0.0');
    
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap', array(), null);
    
    // Main JavaScript
    wp_enqueue_script('rental-main-js', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true);
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
    
    // Localize script for AJAX
    wp_localize_script('rental-main-js', 'rental_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('rental_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'rental_theme_scripts');

// Register widget areas
function rental_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'rental-car'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here to appear in your sidebar.', 'rental-car'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 1', 'rental-car'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here for footer column 1.', 'rental-car'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 2', 'rental-car'),
        'id'            => 'footer-2',
        'description'   => __('Add widgets here for footer column 2.', 'rental-car'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 3', 'rental-car'),
        'id'            => 'footer-3',
        'description'   => __('Add widgets here for footer column 3.', 'rental-car'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'rental_widgets_init');

// Customizer settings
function rental_theme_customize_register($wp_customize) {
    // Site Identity
    $wp_customize->get_setting('blogname')->transport = 'postMessage';
    $wp_customize->get_setting('blogdescription')->transport = 'postMessage';
    
    // Colors Section
    $wp_customize->add_section('colors_section', array(
        'title' => __('Theme Colors', 'rental-car'),
        'priority' => 30,
    ));
    
    // Primary Color
    $wp_customize->add_setting('primary_color', array(
        'default' => '#2c3e50',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label' => __('Primary Color', 'rental-car'),
        'section' => 'colors_section',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('secondary_color', array(
        'default' => '#e74c3c',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', array(
        'label' => __('Secondary Color', 'rental-car'),
        'section' => 'colors_section',
    )));
    
    // Hero Section
    $wp_customize->add_section('hero_section', array(
        'title' => __('Hero Section', 'rental-car'),
        'priority' => 40,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Rent a Car in Minutes',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'rental-car'),
        'section' => 'hero_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_description', array(
        'default' => 'Find the perfect vehicle for your needs at affordable prices',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'rental-car'),
        'section' => 'hero_section',
        'type' => 'textarea',
    ));
    
    $wp_customize->add_setting('hero_button_text', array(
        'default' => 'View Cars',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_button_text', array(
        'label' => __('Hero Button Text', 'rental-car'),
        'section' => 'hero_section',
        'type' => 'text',
    ));
    
    // Footer Section
    $wp_customize->add_section('footer_section', array(
        'title' => __('Footer Settings', 'rental-car'),
        'priority' => 50,
    ));
    
    $wp_customize->add_setting('footer_copyright', array(
        'default' => '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('footer_copyright', array(
        'label' => __('Copyright Text', 'rental-car'),
        'section' => 'footer_section',
        'type' => 'text',
    ));
    
    // Social Media
    $wp_customize->add_section('social_media', array(
        'title' => __('Social Media', 'rental-car'),
        'priority' => 60,
    ));
    
    $social_platforms = array('facebook', 'twitter', 'instagram', 'linkedin', 'youtube');
    
    foreach ($social_platforms as $platform) {
        $wp_customize->add_setting($platform . '_url', array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw',
        ));
        
        $wp_customize->add_control($platform . '_url', array(
            'label' => ucfirst($platform) . ' URL',
            'section' => 'social_media',
            'type' => 'url',
        ));
    }
}
add_action('customize_register', 'rental_theme_customize_register');

// Custom CSS from Customizer
function rental_customizer_css() {
    ?>
    <style type="text/css">
        :root {
            --primary: <?php echo get_theme_mod('primary_color', '#2c3e50'); ?>;
            --secondary: <?php echo get_theme_mod('secondary_color', '#e74c3c'); ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'rental_customizer_css');

// Custom post type for Cars
function rental_car_post_type() {
    $labels = array(
        'name' => __('Cars', 'rental-car'),
        'singular_name' => __('Car', 'rental-car'),
        'menu_name' => __('Cars', 'rental-car'),
        'name_admin_bar' => __('Car', 'rental-car'),
        'add_new' => __('Add New', 'rental-car'),
        'add_new_item' => __('Add New Car', 'rental-car'),
        'new_item' => __('New Car', 'rental-car'),
        'edit_item' => __('Edit Car', 'rental-car'),
        'view_item' => __('View Car', 'rental-car'),
        'all_items' => __('All Cars', 'rental-car'),
        'search_items' => __('Search Cars', 'rental-car'),
        'not_found' => __('No cars found.', 'rental-car'),
        'not_found_in_trash' => __('No cars found in Trash.', 'rental-car')
    );
    
    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'cars'),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-car',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true,
    );
    
    register_post_type('car', $args);
}
add_action('init', 'rental_car_post_type');

// Custom taxonomy for Car Types
function rental_car_taxonomy() {
    $labels = array(
        'name' => __('Car Types', 'rental-car'),
        'singular_name' => __('Car Type', 'rental-car'),
        'search_items' => __('Search Car Types', 'rental-car'),
        'all_items' => __('All Car Types', 'rental-car'),
        'edit_item' => __('Edit Car Type', 'rental-car'),
        'update_item' => __('Update Car Type', 'rental-car'),
        'add_new_item' => __('Add New Car Type', 'rental-car'),
        'new_item_name' => __('New Car Type Name', 'rental-car'),
        'menu_name' => __('Car Types', 'rental-car'),
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'car-type'),
    );
    
    register_taxonomy('car_type', array('car'), $args);
}
add_action('init', 'rental_car_taxonomy');

// Add theme options page
if (function_exists('acf_add_options_page')) {
    acf_add_options_page(array(
        'page_title' => 'Theme Settings',
        'menu_title' => 'Theme Settings',
        'menu_slug' => 'theme-settings',
        'capability' => 'edit_posts',
        'redirect' => false
    ));
}

// Security: Remove WordPress version
function rental_remove_version() {
    return '';
}
add_filter('the_generator', 'rental_remove_version');

// Security: Disable XML-RPC
add_filter('xmlrpc_enabled', '__return_false');

// Custom excerpt length
function rental_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'rental_excerpt_length');

// Custom excerpt more
function rental_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'rental_excerpt_more');

// Add body classes
function rental_body_classes($classes) {
    if (is_singular()) {
        $classes[] = 'singular';
    }
    
    if (is_front_page()) {
        $classes[] = 'front-page';
    }
    
    return $classes;
}
add_filter('body_class', 'rental_body_classes');

// AJAX handler example
function rental_ajax_handler() {
    check_ajax_referer('rental_nonce', 'nonce');
    
    // Your AJAX logic here
    
    wp_die();
}
add_action('wp_ajax_rental_action', 'rental_ajax_handler');
add_action('wp_ajax_nopriv_rental_action', 'rental_ajax_handler');
?>