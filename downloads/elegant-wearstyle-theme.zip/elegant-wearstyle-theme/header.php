<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?> | <?php bloginfo('description'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header>
    <div class="container">
        <div class="header-content">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                Elegant<span>WearStyle</span>
            </a>
            
            <!-- Desktop Navigation -->
            <nav class="desktop-nav">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary-menu',
                    'container' => false,
                    'fallback_cb' => false,
                    'items_wrap' => '%3$s',
                    'walker' => new Simple_Nav_Walker()
                ));
                ?>
                <a href="<?php echo esc_url(home_url('/shop')); ?>" class="nav-button">Shop Now</a>
            </nav>
            
            <!-- Mobile Menu Button -->
            <button class="mobile-menu-button" id="mobileMenuButton">☰</button>
        </div>
    </div>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav" id="mobileNav">
        <div class="mobile-nav-links">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary-menu',
                'container' => false,
                'fallback_cb' => false,
                'items_wrap' => '%3$s',
                'walker' => new Simple_Nav_Walker_Mobile()
            ));
            ?>
            <a href="<?php echo esc_url(home_url('/shop')); ?>" class="mobile-nav-button">Shop Now</a>
        </div>
    </div>
</header>

<main>