    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column footer-about">
                    <h3><?php bloginfo('name'); ?></h3>
                    <p><?php bloginfo('description'); ?></p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer',
                        'container' => false,
                        'menu_class' => 'footer-links',
                        'fallback_cb' => false,
                    ));
                    ?>
                </div>
                <div class="footer-column">
                    <h3>Popular Courses</h3>
                    <ul class="footer-links">
                        <?php
                        $courses = get_posts(array(
                            'post_type' => 'course',
                            'numberposts' => 5,
                            'orderby' => 'date',
                            'order' => 'DESC'
                        ));
                        
                        foreach ($courses as $course) {
                            echo '<li><a href="' . get_permalink($course->ID) . '"><i class="fas fa-chevron-right"></i> ' . $course->post_title . '</a></li>';
                        }
                        ?>
                    </ul>
                </div>
                <div class="footer-column footer-newsletter">
                    <h3>Newsletter</h3>
                    <p>Subscribe to our newsletter to get updates on new courses and offers.</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your Email">
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                    <p><i class="fas fa-phone"></i> <?php echo get_theme_mod('edulearn_phone', '+1 (123) 456-7890'); ?></p>
                    <p><i class="fas fa-envelope"></i> <?php echo get_theme_mod('edulearn_email', 'info@edulearn.com'); ?></p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All Rights Reserved. | Designed with <i class="fas fa-heart" style="color: #ff6b6b;"></i> for Education</p>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>