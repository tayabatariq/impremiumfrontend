// Simple JavaScript for interactive elements
document.addEventListener('DOMContentLoaded', function() {
    // Search box focus effect
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        searchInput.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    }
    
    // Show more functionality
    const showMoreLinks = document.querySelectorAll('.show-more');
    
    showMoreLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const list = this.previousElementSibling;
            const items = list.querySelectorAll('li');
            
            // Toggle visibility of additional items
            let allVisible = true;
            items.forEach(item => {
                if (item.style.display === 'none') {
                    item.style.display = 'block';
                    allVisible = false;
                }
            });
            
            // If all items are visible, change the text
            if (allVisible) {
                this.textContent = this.textContent.includes('Show All') ? 'Show Less' : 'Show All';
                this.querySelector('i').classList.toggle('fa-chevron-up');
            }
        });
    });
    
    // Mobile menu toggle (you can add this functionality later)
    console.log('AetheriumCore theme loaded successfully!');
});