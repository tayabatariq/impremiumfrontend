<?php
/**
 * The template for displaying all pages
 *
 * @package CyanoraWP
 */

get_header();
?>

<main id="main" class="site-main">
    <section class="hero-section" style="padding: 6rem 0 4rem;">
        <div class="hero-background"></div>
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title" style="font-size: 3.5rem;"><?php the_title(); ?></h1>
                <?php if (get_the_excerpt()) : ?>
                    <p class="hero-description"><?php echo get_the_excerpt(); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="features-section" style="padding: 4rem 0;">
        <div class="container">
            <div class="features-grid">
                <article class="feature-card">
                    <div class="feature-content">
                        <?php
                        if (have_posts()) :
                            while (have_posts()) : the_post();
                                the_content();
                            endwhile;
                        else :
                            echo '<p>' . esc_html__('No content found.', 'cyanorawp') . '</p>';
                        endif;
                        ?>
                    </div>
                </article>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>