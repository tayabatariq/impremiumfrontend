<?php get_header(); ?>

<div class="container">
    <div class="page-content" style="padding: 120px 0 60px; min-height: 50vh;">
        <h1><?php the_title(); ?></h1>
        <div class="content">
            <?php the_content(); ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>