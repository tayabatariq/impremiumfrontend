<?php get_header(); ?>

<div class="container">
    <section class="error-404 not-found">
        <header class="page-header">
            <h1 class="page-title"><?php _e('Page Not Found', 'portfolio-theme'); ?></h1>
        </header>
        
        <div class="page-content">
            <p><?php _e('The page you are looking for does not exist.', 'portfolio-theme'); ?></p>
        </div>
    </section>
</div>

<?php get_footer(); ?>