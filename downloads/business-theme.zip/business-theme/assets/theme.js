// Basic JavaScript for interactivity
document.addEventListener('DOMContentLoaded', function() {
  console.log('Theme loaded successfully!');
  
  // Add hover effects to service cards
  const serviceCards = document.querySelectorAll('.service-card-enhanced');
  serviceCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-5px)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });
});