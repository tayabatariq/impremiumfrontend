<?php
function clothing_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary-menu' => __('Primary Menu', 'clothing-theme')
    ));
}
add_action('after_setup_theme', 'clothing_theme_setup');

// Custom nav walker for desktop
class Simple_Nav_Walker extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $output .= '<a href="' . $item->url . '" class="nav-link">' . $item->title . '</a>';
    }
}

// Custom nav walker for mobile
class Simple_Nav_Walker_Mobile extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $output .= '<a href="' . $item->url . '" class="mobile-nav-link">' . $item->title . '</a>';
    }
}

function clothing_theme_scripts() {
    // Enqueue main stylesheet
    wp_enqueue_style('clothing-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue Google Fonts
    wp_enqueue_style('clothing-google-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Source+Serif+Pro:wght@400;600;700&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'clothing_theme_scripts');

// Add mobile menu JavaScript
function clothing_theme_mobile_menu_script() {
    ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            var mobileMenuButton = document.getElementById('mobileMenuButton');
            var mobileNav = document.getElementById('mobileNav');
            
            if (mobileMenuButton && mobileNav) {
                mobileMenuButton.addEventListener('click', function() {
                    mobileNav.classList.toggle('active');
                });
                
                var mobileLinks = document.querySelectorAll('.mobile-nav-link, .mobile-nav-button');
                mobileLinks.forEach(function(link) {
                    link.addEventListener('click', function() {
                        mobileNav.classList.remove('active');
                    });
                });
                
                document.addEventListener('click', function(e) {
                    if (!e.target.closest('#mobileNav') && !e.target.closest('#mobileMenuButton')) {
                        mobileNav.classList.remove('active');
                    }
                });
            }
        });
    </script>
    <?php
}
add_action('wp_footer', 'clothing_theme_mobile_menu_script');

// Customizer Settings
function clothing_theme_customize_register($wp_customize) {
    
    // Hero Section Settings
    $wp_customize->add_section('hero_section', array(
        'title' => __('Hero Section', 'clothing-theme'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('hero_badge_text', array(
        'default' => 'New Collection',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_badge_text', array(
        'label' => __('Hero Badge Text', 'clothing-theme'),
        'section' => 'hero_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Elevate Your Everyday Style',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'clothing-theme'),
        'section' => 'hero_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_description', array(
        'default' => 'Discover premium clothing crafted with attention to detail, designed for comfort and sophistication in your daily life.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'clothing-theme'),
        'section' => 'hero_section',
        'type' => 'textarea',
    ));
    
    // Features Section Settings
    $wp_customize->add_section('features_section', array(
        'title' => __('Features Section', 'clothing-theme'),
        'priority' => 31,
    ));
    
    $wp_customize->add_setting('features_subtitle', array(
        'default' => 'WHY CHOOSE US',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('features_subtitle', array(
        'label' => __('Features Subtitle', 'clothing-theme'),
        'section' => 'features_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('features_title', array(
        'default' => 'Crafted with Excellence',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('features_title', array(
        'label' => __('Features Title', 'clothing-theme'),
        'section' => 'features_section',
        'type' => 'text',
    ));
    
    // CTA Section Settings
    $wp_customize->add_section('cta_section', array(
        'title' => __('Call to Action Section', 'clothing-theme'),
        'priority' => 32,
    ));
    
    $wp_customize->add_setting('cta_title', array(
        'default' => 'Ready to Elevate Your Wardrobe?',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('cta_title', array(
        'label' => __('CTA Title', 'clothing-theme'),
        'section' => 'cta_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('cta_description', array(
        'default' => 'Join thousands of satisfied customers who have discovered the Clothings difference. Sign up for exclusive offers and early access to new collections.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('cta_description', array(
        'label' => __('CTA Description', 'clothing-theme'),
        'section' => 'cta_section',
        'type' => 'textarea',
    ));
    
    $wp_customize->add_setting('cta_button_text', array(
        'default' => 'Sign Up Now',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('cta_button_text', array(
        'label' => __('CTA Button Text', 'clothing-theme'),
        'section' => 'cta_section',
        'type' => 'text',
    ));
}
add_action('customize_register', 'clothing_theme_customize_register');
?>