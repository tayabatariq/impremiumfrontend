<section class="timeline-section">
    <h2 class="section-title"><?php echo esc_html(get_theme_mod('timeline_section_title', 'Creative Journey')); ?></h2>
    
    <div class="timeline">
        <?php
        $timeline_args = array(
            'post_type' => 'timeline',
            'posts_per_page' => -1,
            'order' => 'DESC',
            'orderby' => 'meta_value_num',
            'meta_key' => 'timeline_year'
        );
        $timeline_query = new WP_Query($timeline_args);
        
        if ($timeline_query->have_posts()) :
            $count = 0;
            while ($timeline_query->have_posts()) : $timeline_query->the_post();
                $count++;
        ?>
            <div class="timeline-item <?php echo ($count % 2 == 0) ? 'even' : 'odd'; ?>">
                <div class="timeline-content">
                    <div class="timeline-year">
                        <?php echo esc_html(get_post_meta(get_the_ID(), 'timeline_year', true)); ?>
                    </div>
                    <div class="timeline-text">
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            // Default timeline
        ?>
            <div class="timeline-item odd">
                <div class="timeline-content">
                    <div class="timeline-year">2023</div>
                    <div class="timeline-text">Developed the adaptive color matrix system and implemented dynamic portfolio features.</div>
                </div>
            </div>
            <div class="timeline-item even">
                <div class="timeline-content">
                    <div class="timeline-year">2021</div>
                    <div class="timeline-text">Explored holographic UI elements and began prototyping interactive grid layouts.</div>
                </div>
            </div>
            <div class="timeline-item odd">
                <div class="timeline-content">
                    <div class="timeline-year">2018</div>
                    <div class="timeline-text">Started research on color psychology in digital interfaces and user experience design.</div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>