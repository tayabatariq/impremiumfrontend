<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?> | <?php is_front_page() ? bloginfo('description') : wp_title(''); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header class="site-header">
        <div class="container">
            <div class="header-top">
                <div class="logo">
                    <?php if (has_custom_logo()): ?>
                        <?php the_custom_logo(); ?>
                    <?php else: ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>">Newus<span>Flow</span></a>
                    <?php endif; ?>
                </div>
                
                <nav class="main-navigation">
                    <?php if (has_nav_menu('primary')): ?>
                        <?php wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'menu_class' => 'nav-menu',
                            'container' => false
                        )); ?>
                    <?php else: ?>
                        <?php newusflow_default_menu(); ?>
                    <?php endif; ?>
                </nav>
                
                <div class="header-search">
                    <form role="search" method="get" action="<?php echo home_url('/'); ?>">
                        <input type="search" placeholder="Search products..." value="<?php echo get_search_query(); ?>" name="s" />
                        <button type="submit">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </header>
    
    <main class="site-main">