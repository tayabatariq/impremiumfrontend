// Portfolio Theme Custom JavaScript

// Mobile Navigation Toggle
document.addEventListener('DOMContentLoaded', function() {
    const burger = document.querySelector('.burger');
    const navLinks = document.querySelector('.nav-links');

    if (burger && navLinks) {
        burger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            burger.classList.toggle('active');
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                burger.classList.remove('active');
            });
        });
    }

    // Dynamic color extraction simulation
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    
    // Simulate color extraction from projects
    const colorPalettes = [
        ['#6c63ff', '#ff6584', '#42e6ff'],
        ['#ff9a3c', '#ff6b6b', '#4ecdc4'],
        ['#a166ab', '#5073b8', '#1098ad']
    ];
    
    portfolioItems.forEach((item, index) => {
        const colors = colorPalettes[index % colorPalettes.length];
        
        // Create dynamic gradient background
        item.style.background = `linear-gradient(135deg, ${colors[0]}20, ${colors[1]}20, ${colors[2]}20)`;
        
        // Add pulsing animation
        item.style.animation = `pulse${index+1} 4s infinite alternate`;
        
        // Create dynamic styles for pulsing
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse${index+1} {
                0% { box-shadow: 0 5px 15px ${colors[0]}40; }
                50% { box-shadow: 0 10px 25px ${colors[1]}50; }
                100% { box-shadow: 0 15px 30px ${colors[2]}60; }
            }
        `;
        document.head.appendChild(style);
    });
    
    // Add scroll effect to navbar
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            if (window.scrollY > 50) {
                navbar.style.background = 'rgba(15, 12, 41, 0.9)';
                navbar.style.backdropFilter = 'blur(15px)';
            } else {
                navbar.style.background = 'var(--glass-bg)';
                navbar.style.backdropFilter = 'blur(10px)';
            }
        }
    });

    // Debug info toggle (remove in production)
    const debugToggle = document.createElement('button');
    debugToggle.innerHTML = '🔧';
    debugToggle.style.position = 'fixed';
    debugToggle.style.bottom = '20px';
    debugToggle.style.right = '20px';
    debugToggle.style.zIndex = '10000';
    debugToggle.style.background = '#ff6b6b';
    debugToggle.style.color = 'white';
    debugToggle.style.border = 'none';
    debugToggle.style.borderRadius = '50%';
    debugToggle.style.width = '50px';
    debugToggle.style.height = '50px';
    debugToggle.style.cursor = 'pointer';
    debugToggle.style.fontSize = '20px';
    
    debugToggle.addEventListener('click', function() {
        const debugInfo = document.getElementById('debug-info');
        if (debugInfo) {
            debugInfo.style.display = debugInfo.style.display === 'none' ? 'block' : 'none';
        }
    });
    
    document.body.appendChild(debugToggle);
});