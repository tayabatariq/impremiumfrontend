    </main>

    <footer>
        <div class="footer-content">
            <?php if (is_active_sidebar('footer-widgets')) : ?>
                <div class="footer-widgets">
                    <?php dynamic_sidebar('footer-widgets'); ?>
                </div>
            <?php endif; ?>
            
            <div class="social-links">
                <?php
                $social_links = array(
                    'twitter' => get_theme_mod('social_twitter'),
                    'facebook' => get_theme_mod('social_facebook'),
                    'instagram' => get_theme_mod('social_instagram'),
                    'linkedin' => get_theme_mod('social_linkedin'),
                    'github' => get_theme_mod('social_github'),
                    'dribbble' => get_theme_mod('social_dribbble'),
                    'behance' => get_theme_mod('social_behance'),
                );
                
                foreach ($social_links as $platform => $url) {
                    if ($url) {
                        echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener"><i class="fab fa-' . esc_attr($platform) . '"></i></a>';
                    }
                }
                ?>
            </div>
            
            <?php
            wp_nav_menu(array(
                'theme_location' => 'footer',
                'menu_class' => 'footer-menu',
                'container' => false,
                'depth' => 1,
            ));
            ?>
            
            <p class="copyright">
                <?php echo wp_kses_post(get_theme_mod('footer_text', '© ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.')); ?>
            </p>
        </div>
    </footer>
    
    <?php wp_footer(); ?>
</body>
</html>