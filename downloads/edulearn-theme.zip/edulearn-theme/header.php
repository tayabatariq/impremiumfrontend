<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <!-- Navigation Header -->
    <nav class="navbar">
        <div class="container nav-container">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                <i class="fas fa-graduation-cap"></i>
                <?php bloginfo('name'); ?>
            </a>
            
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'nav-links',
                'fallback_cb' => false,
            ));
            ?>
            
            <div class="nav-buttons">
                <?php if (is_user_logged_in()): ?>
                    <!-- Show for logged-in users -->
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="nav-btn logout">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                    <a href="<?php echo esc_url(admin_url()); ?>" class="nav-btn dashboard">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                <?php else: ?>
                    <!-- Show for logged-out users -->
                    <a href="<?php echo esc_url(wp_login_url()); ?>" class="nav-btn login">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                    <a href="<?php echo esc_url(wp_registration_url()); ?>" class="nav-btn signup">
                        <i class="fas fa-user-plus"></i> Sign Up
                    </a>
                <?php endif; ?>
            </div>
            
            <div class="mobile-menu">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <!-- Header Section -->
    <header>
        <div class="container">
            <div class="header-content">
                <h1><?php echo get_theme_mod('header_title', get_bloginfo('description')); ?></h1>
                <p><?php echo get_theme_mod('header_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel adipiscing ipsum. Nam neque purus, tincidunt non nisi dapibus, malesuada convallis.'); ?></p>
                <?php
                $courses_page = get_page_by_path('courses');
                $courses_url = $courses_page ? get_permalink($courses_page->ID) : '#';
                ?>
                <a href="<?php echo esc_url($courses_url); ?>" class="btn">View Courses</a>
            </div>
        </div>
    </header>