<?php get_header(); ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1><?php echo get_theme_mod('hero_title', 'Transform Ideas Into <span>Digital Experiences</span>'); ?></h1>
            <p><?php echo get_theme_mod('hero_description', 'I\'m a creative developer specializing in immersive web experiences, interactive design, and cutting-edge digital solutions that captivate and engage audiences.'); ?></p>
            <div class="hero-buttons">
                <a href="#portfolio" class="btn">View My Work</a>
                <a href="#contact" class="btn btn-secondary">Get In Touch</a>
            </div>
        </div>
    </div>
    
    <!-- 3D Interactive Card -->
    <div class="card-container">
        <div class="card-3d">
            <div class="card-face card-front glass">
                <div class="card-icon">
                    <i class="fas fa-lightbulb"></i>
                </div>
                <h3>Creative Vision</h3>
                <p>Hover to discover more</p>
            </div>
            <div class="card-face card-back glass">
                <div class="card-icon">
                    <i class="fas fa-rocket"></i>
                </div>
                <h3>Innovation</h3>
                <p>Pushing boundaries in digital design</p>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about" class="about">
    <div class="container">
        <div class="about-content">
            <div class="about-text">
                <h2><?php echo get_theme_mod('about_title', 'About Me'); ?></h2>
                <p><?php echo get_theme_mod('about_content', 'I\'m a passionate digital creator with over 7 years of experience in crafting unique web experiences. My approach combines technical expertise with artistic vision to deliver solutions that are both functional and beautiful.'); ?></p>
                <p>I specialize in front-end development, UI/UX design, and interactive experiences that push the boundaries of what's possible on the web.</p>
                
                <div class="skills">
                    <div class="skill">Web Development</div>
                    <div class="skill">UI/UX Design</div>
                    <div class="skill">Interactive Design</div>
                    <div class="skill">3D Graphics</div>
                    <div class="skill">Motion Design</div>
                    <div class="skill">Creative Coding</div>
                </div>
            </div>
            
            <div class="about-visual">
                <div class="floating-shapes">
                    <div class="shape glass">
                        <i class="fas fa-code"></i>
                    </div>
                    <div class="shape glass">
                        <i class="fas fa-palette"></i>
                    </div>
                    <div class="shape glass">
                        <i class="fas fa-cube"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Section -->
<section id="portfolio" class="portfolio">
    <div class="container">
        <div class="section-title">
            <h2>Featured Work</h2>
            <p>A selection of my recent projects</p>
        </div>
        
        <div class="portfolio-grid">
            <?php
            $portfolio_args = array(
                'post_type' => 'portfolio',
                'posts_per_page' => 6,
                'post_status' => 'publish'
            );
            $portfolio_query = new WP_Query($portfolio_args);
            
            if ($portfolio_query->have_posts()) :
                while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                    $thumbnail_url = get_the_post_thumbnail_url() ?: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1064&q=80';
            ?>
                <div class="portfolio-item glass">
                    <img src="<?php echo $thumbnail_url; ?>" alt="<?php the_title(); ?>" class="portfolio-img">
                    <div class="portfolio-info">
                        <h3><?php the_title(); ?></h3>
                        <p><?php echo get_the_excerpt(); ?></p>
                        <div class="portfolio-tags">
                            <div class="tag">Web Design</div>
                            <div class="tag">Development</div>
                        </div>
                    </div>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <!-- Default portfolio items if no portfolio posts exist -->
                <div class="portfolio-item glass">
                    <img src="https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1064&q=80" alt="Project 1" class="portfolio-img">
                    <div class="portfolio-info">
                        <h3>Immersive Web Experience</h3>
                        <p>An interactive website with 3D elements and smooth animations</p>
                        <div class="portfolio-tags">
                            <div class="tag">WebGL</div>
                            <div class="tag">Three.js</div>
                            <div class="tag">GSAP</div>
                        </div>
                    </div>
                </div>
                
                <div class="portfolio-item glass">
                    <img src="https://images.unsplash.com/photo-1555099962-419945c0fd50?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80" alt="Project 2" class="portfolio-img">
                    <div class="portfolio-info">
                        <h3>Interactive Dashboard</h3>
                        <p>A data visualization platform with real-time updates</p>
                        <div class="portfolio-tags">
                            <div class="tag">React</div>
                            <div class="tag">D3.js</div>
                            <div class="tag">API</div>
                        </div>
                    </div>
                </div>
                
                <div class="portfolio-item glass">
                    <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80" alt="Project 3" class="portfolio-img">
                    <div class="portfolio-info">
                        <h3>Brand Identity System</h3>
                        <p>Complete visual identity for a tech startup</p>
                        <div class="portfolio-tags">
                            <div class="tag">Branding</div>
                            <div class="tag">UI Design</div>
                            <div class="tag">Illustration</div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section id="contact" class="contact">
    <div class="container">
        <div class="section-title">
            <h2>Get In Touch</h2>
            <p>Let's create something amazing together</p>
        </div>
        
        <div class="contact-content">
            <div class="contact-info">
                <div class="contact-item glass">
                    <div class="contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div>
                        <h3>Email</h3>
                        <p><?php echo get_theme_mod('contact_email', 'hello@nexusvision.com'); ?></p>
                    </div>
                </div>
                
                <div class="contact-item glass">
                    <div class="contact-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <div>
                        <h3>Phone</h3>
                        <p><?php echo get_theme_mod('contact_phone', '+1 (555) 123-4567'); ?></p>
                    </div>
                </div>
                
                <div class="contact-item glass">
                    <div class="contact-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div>
                        <h3>Location</h3>
                        <p><?php echo get_theme_mod('contact_location', 'San Francisco, CA'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="contact-form glass">
                <?php echo do_shortcode('[contact-form-7 id="'.get_option('wpcf7_id').'" title="Contact form 1"]'); ?>
                <!-- Fallback form if CF7 is not installed -->
                <?php if (!shortcode_exists('contact-form-7')): ?>
                    <form>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Subject" required>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" placeholder="Your Message" required></textarea>
                        </div>
                        <button type="submit" class="btn">Send Message</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>