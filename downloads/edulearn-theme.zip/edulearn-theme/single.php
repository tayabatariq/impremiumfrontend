<?php get_header(); ?>

<section class="single-content">
    <div class="container">
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
                <div class="entry-meta">
                    <span class="posted-on">Posted on <?php echo get_the_date(); ?></span>
                </div>
            </header>
            
            <div class="entry-content">
                <?php the_content(); ?>
            </div>
            
            <footer class="entry-footer">
                <?php
                if (comments_open() || get_comments_number()) {
                    comments_template();
                }
                ?>
            </footer>
        </article>
    </div>
</section>

<?php get_footer(); ?>