<?php get_header(); ?>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container hero-content">
            <div class="hero-text">
                <span class="hero-badge">New Framework Released</span>
                <h1>Build Exceptional Websites With Premium WordPress Themes</h1>
                <p>Discover our unique collection of professionally designed themes for businesses, creatives, and online stores. Every theme is crafted with precision and attention to detail.</p>
                <div class="hero-actions">
                    <a href="#" class="btn">Explore Themes</a>
                    <a href="#" class="btn btn-secondary">View Demos</a>
                </div>
            </div>
            <div class="hero-visual">
                <div class="visual-card">
                    <div class="card-header">
                        <div class="card-dots">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    <div class="card-content">
                        <h3 class="card-title">Theme Features</h3>
                        <ul class="card-features">
                            <li><i class="fas fa-check-circle"></i> Fully Responsive Design</li>
                            <li><i class="fas fa-check-circle"></i> SEO Optimized</li>
                            <li><i class="fas fa-check-circle"></i> Fast Loading</li>
                            <li><i class="fas fa-check-circle"></i> Customizable Layouts</li>
                            <li><i class="fas fa-check-circle"></i> WooCommerce Ready</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Categories Section -->
    <section class="categories">
        <div class="container">
            <div class="section-header">
                <span class="section-label">Theme Categories</span>
                <h2 class="section-title">Find Your Perfect Theme</h2>
                <p class="section-subtitle">Browse our carefully curated collection of WordPress themes organized by industry and purpose.</p>
            </div>
            <div class="categories-grid">
                <!-- Corporate Category -->
                <div class="category-card">
                    <div class="category-visual">
                        <div class="category-icon">
                            <i class="fas fa-building"></i>
                        </div>
                    </div>
                    <div class="category-content">
                        <h3>Corporate</h3>
                        <p>Professional themes designed for businesses, corporations, and professional services with a focus on credibility and trust.</p>
                        <a href="#" class="category-link">Explore Corporate Themes <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>

                <!-- Creative Category -->
                <div class="category-card">
                    <div class="category-visual">
                        <div class="category-icon">
                            <i class="fas fa-palette"></i>
                        </div>
                    </div>
                    <div class="category-content">
                        <h3>Creative</h3>
                        <p>Artistic and visually striking themes for designers, artists, photographers, and creative professionals showcasing their work.</p>
                        <a href="#" class="category-link">Explore Creative Themes <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>

                <!-- Retail Category -->
                <div class="category-card">
                    <div class="category-visual">
                        <div class="category-icon">
                            <i class="fas fa-store"></i>
                        </div>
                    </div>
                    <div class="category-content">
                        <h3>Retail</h3>
                        <p>Engaging themes for physical stores, boutiques, and retail businesses looking to establish a strong online presence.</p>
                        <a href="#" class="category-link">Explore Retail Themes <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>

                <!-- eCommerce Category -->
                <div class="category-card">
                    <div class="category-visual">
                        <div class="category-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                    </div>
                    <div class="category-content">
                        <h3>eCommerce</h3>
                        <p>Powerful online store themes with seamless WooCommerce integration and conversion-focused designs for maximum sales.</p>
                        <a href="#" class="category-link">Explore eCommerce Themes <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats">
        <div class="container">
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-number">5,247</div>
                    <div class="stat-label">Themes Sold</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">98.7%</div>
                    <div class="stat-label">Satisfaction Rate</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">24/7</div>
                    <div class="stat-label">Customer Support</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">5+</div>
                    <div class="stat-label">Years Experience</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Browse Section -->
    <section class="browse">
        <div class="container">
            <div class="browse-container">
                <div class="browse-header">
                    <h2 class="section-title">Browse Our Collection</h2>
                    <p>Find the perfect theme for your website from our extensive library of premium designs. Each theme is carefully crafted to deliver exceptional performance and user experience.</p>
                    <a href="#" class="btn">View All Themes</a>
                </div>
                <div class="browse-content">
                    <div class="browse-card">
                        <h3><i class="fas fa-star"></i> Browse New</h3>
                        <ul class="browse-list">
                            <li><a href="#">Quantum Corporate <span class="count">New</span></a></li>
                            <li><a href="#">Artisan Studio <span class="count">New</span></a></li>
                            <li><a href="#">Marketplace Pro <span class="count">New</span></a></li>
                            <li><a href="#">ShopGrid <span class="count">New</span></a></li>
                            <li><a href="#">Business Elite <span class="count">New</span></a></li>
                        </ul>
                        <a href="#" class="show-more">Show All New <i class="fas fa-chevron-down"></i></a>
                    </div>
                    <div class="browse-card">
                        <h3><i class="fas fa-fire"></i> Browse Bestsellers</h3>
                        <ul class="browse-list">
                            <li><a href="#">Corporate Plus <span class="count">1,234</span></a></li>
                            <li><a href="#">Creative Canvas <span class="count">987</span></a></li>
                            <li><a href="#">Retail Hub <span class="count">856</span></a></li>
                            <li><a href="#">ShopMaster <span class="count">742</span></a></li>
                            <li><a href="#">Business Pro <span class="count">689</span></a></li>
                        </ul>
                        <a href="#" class="show-more">Show All Bestsellers <i class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Transform Your Website?</h2>
                <p>Join thousands of satisfied customers who have elevated their online presence with our premium WordPress themes. Get started today and create something amazing.</p>
                <a href="#" class="btn">Get Started Now <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </section>

<?php get_footer(); ?>