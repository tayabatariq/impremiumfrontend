<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <!-- Background Elements -->
    <div class="bg-elements">
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
    </div>

    <!-- Header -->
    <header class="site-header">
        <div class="container">
            <nav class="navbar">
                <div class="site-branding">
                    <?php if (has_custom_logo()): ?>
                        <?php the_custom_logo(); ?>
                    <?php else: ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-title">NexusVision</a>
                    <?php endif; ?>
                </div>
                
                <nav class="main-navigation">
                    <?php if (has_nav_menu('primary')): ?>
                        <?php wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'menu_class' => 'nav-menu',
                            'container' => false
                        )); ?>
                    <?php else: ?>
                        <?php nexusvision_default_menu(); ?>
                    <?php endif; ?>
                </nav>
                
                <button class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </button>
            </nav>
        </div>
    </header>
    
    <main class="site-main">