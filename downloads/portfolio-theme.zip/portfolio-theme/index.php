<?php get_header(); ?>

<div class="container">
    <!-- Debug Info -->
    <div style="background: #ff6b6b; color: white; padding: 20px; margin: 20px 0; border-radius: 10px; display: none;" id="debug-info">
        <h3>🔧 Debug Information:</h3>
        <p><strong>Theme Active:</strong> <?php echo wp_get_theme()->get('Name'); ?></p>
        <p><strong>Custom Posts:</strong> 
            <?php 
            $portfolio_count = wp_count_posts('portfolio');
            echo 'Portfolio: ' . $portfolio_count->publish . ' | ';
            $timeline_count = wp_count_posts('timeline');
            echo 'Timeline: ' . $timeline_count->publish;
            ?>
        </p>
        <p><strong>Hero Title:</strong> "<?php echo get_theme_mod('hero_title', 'DEFAULT'); ?>"</p>
    </div>

    <!-- Hero Section -->
    <section class="hero">
        <h1><?php echo get_theme_mod('hero_title', 'Portfolio'); ?></h1>
        <p><?php echo get_theme_mod('hero_description', 'A dynamic showcase of creative work where each project reveals its unique visual signature through adaptive color systems.'); ?></p>
    </section>
    
    <!-- Portfolio Grid -->
    <section class="portfolio-section">
        <h2 class="section-title"><?php echo get_theme_mod('portfolio_section_title', 'Featured Projects'); ?></h2>
        <div class="portfolio-grid">
            <?php
            $portfolio_query = new WP_Query(array(
                'post_type' => array('portfolio', 'post'),
                'posts_per_page' => 3,
                'post_status' => 'publish'
            ));
            
            if ($portfolio_query->have_posts()) :
                while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                    $post_type = get_post_type();
                    $icon = get_post_meta(get_the_ID(), 'portfolio_icon', true);
                    if (!$icon) {
                        $icon = 'fas fa-' . ($post_type == 'portfolio' ? 'palette' : 'file');
                    }
            ?>
                <div class="portfolio-item">
                    <a href="<?php the_permalink(); ?>">
                        <div class="item-content">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="portfolio-image">
                                    <?php the_post_thumbnail('portfolio-medium'); ?>
                                </div>
                            <?php else : ?>
                                <div class="portfolio-image" style="background: linear-gradient(45deg, var(--primary-color), var(--accent-color)); display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-image" style="font-size: 3rem; color: white; opacity: 0.7;"></i>
                                </div>
                            <?php endif; ?>
                            
                            <i class="<?php echo $icon; ?>"></i>
                            <h3><?php the_title(); ?></h3>
                            <p>
                                <?php 
                                if (has_excerpt()) {
                                    echo wp_trim_words(get_the_excerpt(), 10);
                                } else {
                                    echo 'Creative project description...';
                                }
                                ?>
                            </p>
                        </div>
                    </a>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <!-- Sample Projects Fallback -->
                <div class="portfolio-item">
                    <div class="item-content">
                        <i class="fas fa-palette"></i>
                        <h3>Color Dynamics</h3>
                        <p>Interactive color extraction system</p>
                    </div>
                </div>
                <div class="portfolio-item">
                    <div class="item-content">
                        <i class="fas fa-cube"></i>
                        <h3>3D Visualization</h3>
                        <p>Immersive project presentations</p>
                    </div>
                </div>
                <div class="portfolio-item">
                    <div class="item-content">
                        <i class="fas fa-wave-square"></i>
                        <h3>Kinetic Interface</h3>
                        <p>Dynamic, responsive layouts</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Timeline Section -->
    <section class="timeline-section">
        <h2 class="section-title"><?php echo get_theme_mod('timeline_section_title', 'Creative Journey'); ?></h2>
        <div class="timeline">
            <?php
            $timeline_query = new WP_Query(array(
                'post_type' => array('timeline', 'post'),
                'posts_per_page' => 4,
                'meta_key' => 'timeline_year',
                'orderby' => 'meta_value_num',
                'order' => 'DESC'
            ));
            
            if ($timeline_query->have_posts()) :
                $count = 0;
                while ($timeline_query->have_posts()) : $timeline_query->the_post();
                    $count++;
                    $year = get_post_meta(get_the_ID(), 'timeline_year', true);
                    if (!$year) {
                        $year = date('Y', strtotime(get_the_date()));
                    }
            ?>
                <div class="timeline-item <?php echo ($count % 2 == 0) ? 'even' : 'odd'; ?>">
                    <div class="timeline-content">
                        <div class="timeline-year"><?php echo $year; ?></div>
                        <div class="timeline-text">
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <!-- Default Timeline -->
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-year">2023</div>
                        <div class="timeline-text">Developed the adaptive color matrix system and implemented dynamic portfolio features.</div>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-year">2021</div>
                        <div class="timeline-text">Explored holographic UI elements and began prototyping interactive grid layouts.</div>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-year">2018</div>
                        <div class="timeline-text">Started research on color psychology in digital interfaces and user experience design.</div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php get_footer(); ?>