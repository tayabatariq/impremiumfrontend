<?php get_header(); ?>

<div class="container">
    <div class="single-content" style="padding: 120px 0 60px;">
        <?php while (have_posts()) : the_post(); ?>
            <h1><?php the_title(); ?></h1>
            <div class="post-meta">
                <span class="post-date"><?php echo get_the_date(); ?></span>
            </div>
            <div class="post-content">
                <?php the_content(); ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php get_footer(); ?>