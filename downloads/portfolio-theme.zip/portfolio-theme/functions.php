<?php
/**
 * Portfolio Showcase Theme Functions
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme setup
function portfolio_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('custom-background');
    add_theme_support('custom-header');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('align-wide');
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'portfolio-theme'),
        'footer' => __('Footer Menu', 'portfolio-theme'),
    ));
    
    // Add image sizes
    add_image_size('portfolio-large', 800, 600, true);
    add_image_size('portfolio-medium', 400, 300, true);
    add_image_size('portfolio-thumbnail', 200, 200, true);
    
    // Load text domain
    load_theme_textdomain('portfolio-theme', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'portfolio_theme_setup');

// Enqueue scripts and styles
function portfolio_theme_scripts() {
    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    
    // Enqueue theme styles
    wp_enqueue_style('portfolio-theme-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    
    // Enqueue custom CSS
    $custom_css_path = get_template_directory() . '/assets/css/custom.css';
    if (file_exists($custom_css_path)) {
        wp_enqueue_style('portfolio-custom-style', get_template_directory_uri() . '/assets/css/custom.css', array(), wp_get_theme()->get('Version'));
    }
    
    // Enqueue custom JS
    $custom_js_path = get_template_directory() . '/assets/js/custom.js';
    if (file_exists($custom_js_path)) {
        wp_enqueue_script('portfolio-theme-js', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), wp_get_theme()->get('Version'), true);
    }
    
    // Localize script for AJAX
    wp_localize_script('portfolio-theme-js', 'portfolio_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('portfolio_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'portfolio_theme_scripts');

// Include additional files
$inc_files = array(
    'customizer.php',
    'custom-post-types.php',
    'custom-fields.php'
);

foreach ($inc_files as $file) {
    $file_path = get_template_directory() . '/inc/' . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
    }
}

// Widgets initialization
function portfolio_widgets_init() {
    register_sidebar(array(
        'name' => __('Footer Widget Area', 'portfolio-theme'),
        'id' => 'footer-widgets',
        'description' => __('Add widgets here to appear in your footer.', 'portfolio-theme'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    
    register_sidebar(array(
        'name' => __('Sidebar', 'portfolio-theme'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here to appear in your sidebar.', 'portfolio-theme'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'portfolio_widgets_init');

// Custom excerpt length
function portfolio_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'portfolio_excerpt_length');

// Custom excerpt more
function portfolio_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'portfolio_excerpt_more');

// Add body classes
function portfolio_body_classes($classes) {
    if (is_customize_preview()) {
        $classes[] = 'portfolio-customizer';
    }
    return $classes;
}
add_filter('body_class', 'portfolio_body_classes');