<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'imperium-press' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'cy?C;s#O!HdLAS}.El*NXI8=mDXFT>gG-CoOE*RdAmhTx(}BZ _(91c/O,7_>-]E' );
define( 'SECURE_AUTH_KEY',  '2rv,nu%lY[jt,queau,agx4KYM>61!pB61g^EE+SLK-}c#uHI(ZX(qD!z,yBGT/)' );
define( 'LOGGED_IN_KEY',    '7{y6Fi&4&{D2~YFV=ZBX;.rMYpdnc)(:IpJ(;a_LIPZA@y`{M3n3vrFC=qR[IB_E' );
define( 'NONCE_KEY',        'zu!N%]~b,|DFOrAu:z.JMixrp]PxiG`K,f`,d1sJ~SOxe/w6y{(|aL./(>Pi{I|M' );
define( 'AUTH_SALT',        'u3B=ls~Uc5*)H:#41cn#$W0<4yI91vU~)$Zx78E5E+)t$ye2->$hV)g*dE94pk^L' );
define( 'SECURE_AUTH_SALT', 'P2_K;2zDF.tfKKQk80TejJ l@998QMSLJkj~,=3MLyQDpDpx<UIH#P};beWA&>Mt' );
define( 'LOGGED_IN_SALT',   'ZmyPO*V$y:M8x!VQ^3xa$h[yyu1d29|h(7ta_!Sq1S`{;+[<w|Y^5hz`~Jdv,5Ci' );
define( 'NONCE_SALT',       ')!6<FQk8&MxyDj2d06wLp&P~NWxY;_|lQna([=jt&CyCSNU>>30~x~-Vg.8Ac j{' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
