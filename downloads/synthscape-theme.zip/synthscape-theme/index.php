<?php
/**
 * The main template file
 *
 * @package SynthScape
 */

get_header();
?>

<main>
    <section class="section">
        <h2 class="section-title">Welcome to SynthScape</h2>
        <p>Experience the next evolution of digital aesthetics with our enhanced color palette and refined visual elements. SynthScape combines sophisticated design with cutting-edge animations for an unparalleled user experience.</p>
        
        <div class="feature-showcase">
            <div class="feature-content">
                <h3>Advanced Visual Harmony</h3>
                <p>Our refined color scheme creates perfect visual balance while maintaining the futuristic appeal. The new palette includes vibrant blues, energetic corals, soft purples, and fresh greens that work in perfect harmony.</p>
                <p>Every element has been carefully crafted to provide visual interest without overwhelming the senses.</p>
                <a href="#" class="btn btn-accent" style="margin-top: 1.2rem;">
                    <span>Explore Features</span>
                    <span>→</span>
                </a>
            </div>
            <div class="feature-visual synth-pulse"></div>
        </div>
    </section>
    
    <section class="section">
        <h2 class="section-title">Enhanced Features</h2>
        
        <div class="card-grid">
            <div class="card synth-border">
                <div class="card-icon">✨</div>
                <h3 class="card-title">Refined Animations</h3>
                <p>Smooth, purposeful animations that guide the user's attention and enhance interaction without causing distraction.</p>
            </div>
            
            <div class="card synth-border">
                <div class="card-icon">🎨</div>
                <h3 class="card-title">Harmonious Palette</h3>
                <p>Carefully selected colors that work together to create visual hierarchy and improve readability and user experience.</p>
            </div>
            
            <div class="card synth-border">
                <div class="card-icon">⚡</div>
                <h3 class="card-title">Performance Optimized</h3>
                <p>All visual elements are optimized for performance, ensuring smooth animations and fast loading times across all devices.</p>
            </div>
        </div>
    </section>
    
    <section class="section">
        <h2 class="section-title">Experience the Difference</h2>
        <p>The enhanced SynthScape theme represents the pinnacle of digital design, combining aesthetic beauty with functional excellence.</p>
        
        <div style="margin-top: 1.5rem; display: flex; gap: 1rem; flex-wrap: wrap; justify-content: center;">
            <a href="#" class="btn">
                <span>View Demo</span>
            </a>
            <a href="#" class="btn btn-accent">
                <span>Get Started</span>
            </a>
            <a href="#" class="btn">
                <span>Documentation</span>
            </a>
        </div>
    </section>
</main>

<?php
get_footer();