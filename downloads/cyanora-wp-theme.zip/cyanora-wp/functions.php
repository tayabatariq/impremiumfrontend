<?php
/**
 * CyanoraWP functions and definitions
 *
 * @package CyanoraWP
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Theme setup
function cyanorawp_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'cyanorawp'),
    ));
}
add_action('after_setup_theme', 'cyanorawp_setup');

// Enqueue styles and scripts
function cyanorawp_scripts() {
    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
    
    // Enqueue theme stylesheet
    wp_enqueue_style('cyanorawp-style', get_stylesheet_uri());
    
    // Enqueue custom JavaScript
    wp_enqueue_script('cyanorawp-script', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'cyanorawp_scripts');
?>