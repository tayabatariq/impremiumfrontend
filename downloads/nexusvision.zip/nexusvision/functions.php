<?php
/**
 * NexusVision Theme functions and definitions
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme setup
function nexusvision_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('align-wide');
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'nexusvision'),
        'footer' => __('Footer Menu', 'nexusvision')
    ));
    
    // Add theme support for custom background
    add_theme_support('custom-background');
}
add_action('after_setup_theme', 'nexusvision_theme_setup');

// Enqueue styles and scripts
function nexusvision_scripts() {
    // Main stylesheet
    wp_enqueue_style('nexusvision-style', get_stylesheet_uri());
    
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
    
    // Custom JavaScript
    wp_enqueue_script('nexusvision-script', get_template_directory_uri() . '/assets/js/custom.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'nexusvision_scripts');

// Customizer settings
function nexusvision_customize_register($wp_customize) {
    // Hero Section
    $wp_customize->add_section('nexusvision_hero_section', array(
        'title' => __('Hero Section', 'nexusvision'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Transform Ideas Into <span>Digital Experiences</span>',
        'sanitize_callback' => 'wp_kses_post',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'nexusvision'),
        'section' => 'nexusvision_hero_section',
        'type' => 'textarea',
    ));
    
    $wp_customize->add_setting('hero_description', array(
        'default' => 'I\'m a creative developer specializing in immersive web experiences, interactive design, and cutting-edge digital solutions that captivate and engage audiences.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'nexusvision'),
        'section' => 'nexusvision_hero_section',
        'type' => 'textarea',
    ));
    
    // About Section
    $wp_customize->add_section('nexusvision_about_section', array(
        'title' => __('About Section', 'nexusvision'),
        'priority' => 35,
    ));
    
    $wp_customize->add_setting('about_title', array(
        'default' => 'About Me',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('about_title', array(
        'label' => __('About Title', 'nexusvision'),
        'section' => 'nexusvision_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('about_content', array(
        'default' => 'I\'m a passionate digital creator with over 7 years of experience in crafting unique web experiences. My approach combines technical expertise with artistic vision to deliver solutions that are both functional and beautiful.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('about_content', array(
        'label' => __('About Content', 'nexusvision'),
        'section' => 'nexusvision_about_section',
        'type' => 'textarea',
    ));
    
    // Contact Section
    $wp_customize->add_section('nexusvision_contact_section', array(
        'title' => __('Contact Section', 'nexusvision'),
        'priority' => 40,
    ));
    
    $wp_customize->add_setting('contact_email', array(
        'default' => 'hello@nexusvision.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('contact_email', array(
        'label' => __('Contact Email', 'nexusvision'),
        'section' => 'nexusvision_contact_section',
        'type' => 'email',
    ));
    
    $wp_customize->add_setting('contact_phone', array(
        'default' => '+1 (555) 123-4567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('contact_phone', array(
        'label' => __('Contact Phone', 'nexusvision'),
        'section' => 'nexusvision_contact_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('contact_location', array(
        'default' => 'San Francisco, CA',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('contact_location', array(
        'label' => __('Contact Location', 'nexusvision'),
        'section' => 'nexusvision_contact_section',
        'type' => 'text',
    ));
}
add_action('customize_register', 'nexusvision_customize_register');

// Default menu fallback
function nexusvision_default_menu() {
    echo '<ul class="nav-menu">';
    echo '<li><a href="'.home_url().'">Home</a></li>';
    echo '<li><a href="'.home_url('/about').'">About</a></li>';
    echo '<li><a href="'.home_url('/portfolio').'">Portfolio</a></li>';
    echo '<li><a href="'.home_url('/contact').'">Contact</a></li>';
    echo '</ul>';
}

// Custom Post Type for Portfolio
function nexusvision_portfolio_post_type() {
    register_post_type('portfolio',
        array(
            'labels' => array(
                'name' => __('Portfolio', 'nexusvision'),
                'singular_name' => __('Portfolio Item', 'nexusvision')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'menu_icon' => 'dashicons-portfolio',
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'nexusvision_portfolio_post_type');
?>