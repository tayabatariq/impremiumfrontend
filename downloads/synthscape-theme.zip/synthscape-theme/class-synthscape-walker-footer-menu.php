<?php
/**
 * Custom footer navigation walker for SynthScape theme
 */

class SynthScape_Walker_Footer_Menu extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $output .= '<a href="' . esc_url($item->url) . '" class="footer-link">';
        $output .= esc_html($item->title);
        $output .= '</a>';
    }
}