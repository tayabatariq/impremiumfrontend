<?php
/**
 * Custom Post Types for Portfolio Theme
 */

// Custom Post Types
function portfolio_register_cpt() {
    // Portfolio Items CPT
    $portfolio_labels = array(
        'name' => _x('Portfolio Items', 'Post Type General Name', 'portfolio-theme'),
        'singular_name' => _x('Portfolio Item', 'Post Type Singular Name', 'portfolio-theme'),
        'menu_name' => __('Portfolio', 'portfolio-theme'),
        'all_items' => __('All Portfolio Items', 'portfolio-theme'),
        'view_item' => __('View Portfolio Item', 'portfolio-theme'),
        'add_new_item' => __('Add New Portfolio Item', 'portfolio-theme'),
        'add_new' => __('Add New', 'portfolio-theme'),
        'edit_item' => __('Edit Portfolio Item', 'portfolio-theme'),
        'update_item' => __('Update Portfolio Item', 'portfolio-theme'),
        'search_items' => __('Search Portfolio Items', 'portfolio-theme'),
    );

    $portfolio_args = array(
        'label' => __('Portfolio', 'portfolio-theme'),
        'labels' => $portfolio_labels,
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'menu_icon' => 'dashicons-portfolio',
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'portfolio'),
    );
    register_post_type('portfolio', $portfolio_args);
    
    // Timeline Events CPT
    $timeline_labels = array(
        'name' => _x('Timeline Events', 'Post Type General Name', 'portfolio-theme'),
        'singular_name' => _x('Timeline Event', 'Post Type Singular Name', 'portfolio-theme'),
        'menu_name' => __('Timeline', 'portfolio-theme'),
        'all_items' => __('All Timeline Events', 'portfolio-theme'),
    );

    $timeline_args = array(
        'label' => __('Timeline Events', 'portfolio-theme'),
        'labels' => $timeline_labels,
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'custom-fields'),
        'menu_icon' => 'dashicons-backup',
        'show_in_rest' => true,
    );
    register_post_type('timeline', $timeline_args);
}
add_action('init', 'portfolio_register_cpt');

// Custom Taxonomy for Portfolio
function portfolio_register_taxonomies() {
    $category_labels = array(
        'name' => _x('Portfolio Categories', 'Taxonomy General Name', 'portfolio-theme'),
        'singular_name' => _x('Portfolio Category', 'Taxonomy Singular Name', 'portfolio-theme'),
        'menu_name' => __('Categories', 'portfolio-theme'),
    );

    $category_args = array(
        'labels' => $category_labels,
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
    );
    register_taxonomy('portfolio_category', array('portfolio'), $category_args);
}
add_action('init', 'portfolio_register_taxonomies');

// Fallback menu function
function portfolio_fallback_menu() {
    ?>
    <div class="nav-links">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="active">Home</a>
        <a href="<?php echo esc_url(home_url('/portfolio')); ?>">Work</a>
        <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
        <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    </div>
    <?php
}