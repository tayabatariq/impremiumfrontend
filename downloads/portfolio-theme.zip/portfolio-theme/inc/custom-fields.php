<?php
/**
 * Custom Fields for Portfolio Theme
 */

// Add meta boxes for portfolio items
function portfolio_add_meta_boxes() {
    add_meta_box(
        'portfolio_details',
        __('Portfolio Details', 'portfolio-theme'),
        'portfolio_meta_box_callback',
        'portfolio',
        'normal',
        'high'
    );
    
    add_meta_box(
        'timeline_details',
        __('Timeline Details', 'portfolio-theme'),
        'timeline_meta_box_callback',
        'timeline',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'portfolio_add_meta_boxes');

// Portfolio meta box callback
function portfolio_meta_box_callback($post) {
    wp_nonce_field('portfolio_save_meta', 'portfolio_nonce');
    
    $icon = get_post_meta($post->ID, 'portfolio_icon', true);
    $featured = get_post_meta($post->ID, '_featured_portfolio', true);
    $project_url = get_post_meta($post->ID, 'project_url', true);
    $client_name = get_post_meta($post->ID, 'client_name', true);
    ?>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div>
            <p>
                <label for="portfolio_icon"><strong><?php _e('Font Awesome Icon', 'portfolio-theme'); ?></strong></label><br>
                <input type="text" id="portfolio_icon" name="portfolio_icon" value="<?php echo esc_attr($icon ?: 'fas fa-palette'); ?>" style="width: 100%;" placeholder="fas fa-palette">
                <small><?php _e('Enter Font Awesome icon class', 'portfolio-theme'); ?></small>
            </p>
            
            <p>
                <label for="project_url"><strong><?php _e('Project URL', 'portfolio-theme'); ?></strong></label><br>
                <input type="url" id="project_url" name="project_url" value="<?php echo esc_url($project_url); ?>" style="width: 100%;" placeholder="https://example.com">
            </p>
        </div>
        
        <div>
            <p>
                <label for="client_name"><strong><?php _e('Client Name', 'portfolio-theme'); ?></strong></label><br>
                <input type="text" id="client_name" name="client_name" value="<?php echo esc_attr($client_name); ?>" style="width: 100%;" placeholder="Client Company">
            </p>
            
            <p>
                <input type="checkbox" id="featured_portfolio" name="featured_portfolio" value="yes" <?php checked($featured, 'yes'); ?>>
                <label for="featured_portfolio"><strong><?php _e('Feature this project', 'portfolio-theme'); ?></strong></label>
            </p>
        </div>
    </div>
    <?php
}

// Timeline meta box callback
function timeline_meta_box_callback($post) {
    wp_nonce_field('timeline_save_meta', 'timeline_nonce');
    
    $year = get_post_meta($post->ID, 'timeline_year', true);
    $icon = get_post_meta($post->ID, 'timeline_icon', true);
    ?>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <p>
            <label for="timeline_year"><strong><?php _e('Year', 'portfolio-theme'); ?></strong></label><br>
            <input type="number" id="timeline_year" name="timeline_year" value="<?php echo esc_attr($year ?: date('Y')); ?>" min="1900" max="<?php echo date('Y'); ?>" style="width: 100%;">
        </p>
        
        <p>
            <label for="timeline_icon"><strong><?php _e('Timeline Icon', 'portfolio-theme'); ?></strong></label><br>
            <input type="text" id="timeline_icon" name="timeline_icon" value="<?php echo esc_attr($icon ?: 'fas fa-star'); ?>" style="width: 100%;" placeholder="fas fa-star">
        </p>
    </div>
    <?php
}

// Save meta boxes
function portfolio_save_meta($post_id) {
    // Check if nonce is set
    if (!isset($_POST['portfolio_nonce']) && !isset($_POST['timeline_nonce'])) {
        return;
    }
    
    // Verify nonces
    if (isset($_POST['portfolio_nonce']) && !wp_verify_nonce($_POST['portfolio_nonce'], 'portfolio_save_meta')) {
        return;
    }
    
    if (isset($_POST['timeline_nonce']) && !wp_verify_nonce($_POST['timeline_nonce'], 'timeline_save_meta')) {
        return;
    }
    
    // Check if autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Save portfolio fields
    if (isset($_POST['portfolio_icon'])) {
        update_post_meta($post_id, 'portfolio_icon', sanitize_text_field($_POST['portfolio_icon']));
    }
    
    if (isset($_POST['project_url'])) {
        update_post_meta($post_id, 'project_url', esc_url_raw($_POST['project_url']));
    }
    
    if (isset($_POST['client_name'])) {
        update_post_meta($post_id, 'client_name', sanitize_text_field($_POST['client_name']));
    }
    
    $featured = isset($_POST['featured_portfolio']) ? 'yes' : 'no';
    update_post_meta($post_id, '_featured_portfolio', $featured);
    
    // Save timeline fields
    if (isset($_POST['timeline_year'])) {
        update_post_meta($post_id, 'timeline_year', intval($_POST['timeline_year']));
    }
    
    if (isset($_POST['timeline_icon'])) {
        update_post_meta($post_id, 'timeline_icon', sanitize_text_field($_POST['timeline_icon']));
    }
}
add_action('save_post', 'portfolio_save_meta');