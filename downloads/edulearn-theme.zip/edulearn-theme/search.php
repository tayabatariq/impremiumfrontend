<?php get_header(); ?>

<section class="search-results">
    <div class="container">
        <h1>Search Results for: "<?php echo get_search_query(); ?>"</h1>
        
        <?php if (have_posts()) : ?>
            <div class="search-results-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="search-result-item">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="search-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
            
            <div class="pagination">
                <?php the_posts_pagination(); ?>
            </div>
        <?php else : ?>
            <p>No results found. Please try again with different keywords.</p>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>