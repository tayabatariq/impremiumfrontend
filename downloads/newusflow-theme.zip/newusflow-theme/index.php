<?php get_header(); ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1><?php echo get_theme_mod('hero_title', 'Elevate Your Shopping Experience'); ?></h1>
        <p><?php echo get_theme_mod('hero_description', 'Discover the latest trends with our curated collection of premium products. From fashion to electronics, we bring you the best from around the world.'); ?></p>
        <div class="hero-buttons">
            <a href="<?php echo home_url('/shop'); ?>" class="btn">Shop Now</a>
            <a href="<?php echo home_url('/deals'); ?>" class="btn btn-outline">Explore Deals</a>
        </div>
    </div>
</section>

<!-- Categories Section -->
<section class="section">
    <div class="container">
        <div class="section-title">
            <h2>Shop By Category</h2>
            <p>Browse through our diverse range of product categories</p>
        </div>
        
        <div class="categories">
            <div class="category-card">
                <span class="category-icon">👕</span>
                <h3>Fashion</h3>
                <p class="product-count">1,240 Products</p>
                <a href="<?php echo home_url('/fashion'); ?>" class="btn btn-outline" style="color: var(--primary); border-color: var(--primary);">Shop Now</a>
            </div>
            
            <div class="category-card">
                <span class="category-icon">📱</span>
                <h3>Electronics</h3>
                <p class="product-count">890 Products</p>
                <a href="<?php echo home_url('/electronics'); ?>" class="btn btn-outline" style="color: var(--primary); border-color: var(--primary);">Shop Now</a>
            </div>
            
            <div class="category-card">
                <span class="category-icon">🏡</span>
                <h3>Home & Garden</h3>
                <p class="product-count">756 Products</p>
                <a href="<?php echo home_url('/home-garden'); ?>" class="btn btn-outline" style="color: var(--primary); border-color: var(--primary);">Shop Now</a>
            </div>
            
            <div class="category-card">
                <span class="category-icon">💄</span>
                <h3>Health & Beauty</h3>
                <p class="product-count">542 Products</p>
                <a href="<?php echo home_url('/health-beauty'); ?>" class="btn btn-outline" style="color: var(--primary); border-color: var(--primary);">Shop Now</a>
            </div>
        </div>
    </div>
</section>

<!-- Featured Products Section -->
<section class="section bg-light">
    <div class="container">
        <div class="section-title">
            <h2>Featured Products</h2>
            <p>Handpicked items just for you</p>
        </div>
        
        <div class="products">
            <!-- Product 1 -->
            <div class="product-card">
                <div class="product-image">
                    <span class="product-badge">New</span>
                    <img src="https://via.placeholder.com/300x300?text=Wireless+Headphones" alt="Wireless Headphones">
                </div>
                <div class="product-info">
                    <p class="product-category">Electronics</p>
                    <h3 class="product-title">
                        <a href="<?php echo home_url('/product/wireless-headphones'); ?>">Premium Wireless Headphones</a>
                    </h3>
                    <div class="product-rating">★★★★☆ (128)</div>
                    <div class="product-price">
                        <span class="current-price">$149.99</span>
                        <span class="original-price">$199.99</span>
                    </div>
                    <a href="<?php echo home_url('/cart'); ?>" class="btn">Add to Cart</a>
                </div>
            </div>
            
            <!-- Product 2 -->
            <div class="product-card">
                <div class="product-image">
                    <span class="product-badge">Sale</span>
                    <img src="https://via.placeholder.com/300x300?text=Smart+Watch" alt="Smart Watch">
                </div>
                <div class="product-info">
                    <p class="product-category">Electronics</p>
                    <h3 class="product-title">
                        <a href="<?php echo home_url('/product/smart-watch'); ?>">Smart Watch Series 5</a>
                    </h3>
                    <div class="product-rating">★★★★☆ (96)</div>
                    <div class="product-price">
                        <span class="current-price">$229.99</span>
                        <span class="original-price">$299.99</span>
                    </div>
                    <a href="<?php echo home_url('/cart'); ?>" class="btn">Add to Cart</a>
                </div>
            </div>
            
            <!-- Product 3 -->
            <div class="product-card">
                <div class="product-image">
                    <span class="product-badge">Popular</span>
                    <img src="https://via.placeholder.com/300x300?text=Running+Shoes" alt="Running Shoes">
                </div>
                <div class="product-info">
                    <p class="product-category">Fashion</p>
                    <h3 class="product-title">
                        <a href="<?php echo home_url('/product/running-shoes'); ?>">Premium Running Shoes</a>
                    </h3>
                    <div class="product-rating">★★★★☆ (204)</div>
                    <div class="product-price">
                        <span class="current-price">$129.99</span>
                    </div>
                    <a href="<?php echo home_url('/cart'); ?>" class="btn">Add to Cart</a>
                </div>
            </div>
            
            <!-- Product 4 -->
            <div class="product-card">
                <div class="product-image">
                    <span class="product-badge">Popular</span>
                    <img src="https://via.placeholder.com/300x300?text=Travel+Backpack" alt="Travel Backpack">
                </div>
                <div class="product-info">
                    <p class="product-category">Accessories</p>
                    <h3 class="product-title">
                        <a href="<?php echo home_url('/product/travel-backpack'); ?>">Urban Travel Backpack</a>
                    </h3>
                    <div class="product-rating">★★★★☆ (167)</div>
                    <div class="product-price">
                        <span class="current-price">$79.99</span>
                        <span class="original-price">$99.99</span>
                    </div>
                    <a href="<?php echo home_url('/cart'); ?>" class="btn">Add to Cart</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Newsletter Section -->
<section class="newsletter">
    <div class="container">
        <div class="section-title">
            <h2>Stay Updated</h2>
            <p>Subscribe to our newsletter for exclusive deals and new product alerts</p>
        </div>
        <form class="newsletter-form">
            <input type="email" placeholder="Your email address" required>
            <button type="submit">Subscribe</button>
        </form>
    </div>
</section>

<?php get_footer(); ?>