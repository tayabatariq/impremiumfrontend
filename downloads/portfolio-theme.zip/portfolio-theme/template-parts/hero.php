<?php
$hero_title = get_theme_mod('hero_title', 'Portfolio');
$hero_description = get_theme_mod('hero_description', 'A dynamic showcase of creative work where each project reveals its unique visual signature through adaptive color systems.');
?>

<section class="hero">
    <h1><?php echo esc_html($hero_title); ?></h1>
    <p><?php echo wp_kses_post($hero_description); ?></p>
</section>