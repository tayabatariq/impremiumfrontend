<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
    
<!-- Holographic Navigation -->
<nav class="navbar">
    <div class="logo">
        <?php
        if (has_custom_logo()) {
            the_custom_logo();
        } else {
            echo '<a href="' . esc_url(home_url('/')) . '">' . esc_html(get_bloginfo('name')) . '</a>';
        }
        ?>
    </div>
    
    <?php
    wp_nav_menu(array(
        'theme_location' => 'primary',
        'menu_class' => 'nav-links',
        'container' => false,
        'fallback_cb' => 'portfolio_fallback_menu',
    ));
    ?>
    
    <div class="burger">
        <div></div>
        <div></div>
        <div></div>
    </div>
</nav>

<main id="main">