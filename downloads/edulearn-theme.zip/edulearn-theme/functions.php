<?php
/**
 * EduLearn Theme functions and definitions
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Theme setup
function edulearn_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'edulearn'),
        'footer' => __('Footer Menu', 'edulearn'),
    ));
    
    // Add image sizes
    add_image_size('course-thumbnail', 400, 300, true);
}
add_action('after_setup_theme', 'edulearn_theme_setup');

// Enqueue styles and scripts
function edulearn_scripts() {
    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
    
    // Enqueue theme styles
    wp_enqueue_style('edulearn-style', get_stylesheet_uri());
    wp_enqueue_style('edulearn-custom', get_template_directory_uri() . '/assets/css/custom.css', array(), '1.0.0');
    
    // Enqueue scripts
    wp_enqueue_script('edulearn-custom', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'edulearn_scripts');

// Customizer settings
function edulearn_customize_register($wp_customize) {
    // Add theme options section
    $wp_customize->add_section('edulearn_theme_options', array(
        'title' => __('Theme Options', 'edulearn'),
        'priority' => 30,
    ));
    
    // Add phone number setting
    $wp_customize->add_setting('edulearn_phone', array(
        'default' => '+1 (123) 456-7890',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('edulearn_phone', array(
        'label' => __('Phone Number', 'edulearn'),
        'section' => 'edulearn_theme_options',
        'type' => 'text',
    ));
    
    // Add email setting
    $wp_customize->add_setting('edulearn_email', array(
        'default' => 'info@edulearn.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('edulearn_email', array(
        'label' => __('Email Address', 'edulearn'),
        'section' => 'edulearn_theme_options',
        'type' => 'email',
    ));
}
add_action('customize_register', 'edulearn_customize_register');

// Custom Post Type for Courses
function edulearn_custom_post_types() {
    register_post_type('course',
        array(
            'labels' => array(
                'name' => __('Courses', 'edulearn'),
                'singular_name' => __('Course', 'edulearn')
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'courses'),
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'menu_icon' => 'dashicons-welcome-learn-more',
        )
    );
}
add_action('init', 'edulearn_custom_post_types');