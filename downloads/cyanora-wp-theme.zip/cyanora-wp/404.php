<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package CyanoraWP
 */

get_header();
?>

<main id="main" class="site-main">
    <section class="hero-section">
        <div class="hero-background"></div>
        <div class="container">
            <div class="hero-content">
                <div class="hero-badge" style="background: rgba(239, 68, 68, 0.2); color: #fca5a5; border-color: #dc2626;">
                    <i class="fas fa-exclamation-triangle"></i>
                    ERROR 404
                </div>
                <h1 class="hero-title">Page Not Found</h1>
                <p class="hero-description">The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
                <div class="hero-actions">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">
                        <i class="fas fa-home"></i>
                        Back to Homepage
                    </a>
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-secondary">
                        <i class="fas fa-newspaper"></i>
                        Visit Our Blog
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="features-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Maybe You Were Looking For</h2>
                <p class="section-description">Here are some popular pages that might help you find what you need.</p>
            </div>
            
            <div class="hexagon-grid">
                <div class="hexagon-item">
                    <div class="feature-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <h3 class="feature-title">Homepage</h3>
                    <p class="feature-description">Return to our main homepage and explore our offerings.</p>
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary" style="margin-top: 1rem;">Go Home</a>
                </div>
                
                <div class="hexagon-item">
                    <div class="feature-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h3 class="feature-title">Contact Us</h3>
                    <p class="feature-description">Get in touch with our team for assistance and support.</p>
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary" style="margin-top: 1rem;">Contact</a>
                </div>
                
                <div class="hexagon-item">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3 class="feature-title">Search</h3>
                    <p class="feature-description">Use our search feature to find specific content.</p>
                    <div style="margin-top: 1rem;">
                        <?php get_search_form(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>